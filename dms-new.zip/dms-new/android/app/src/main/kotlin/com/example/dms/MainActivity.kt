package com.example.dms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
