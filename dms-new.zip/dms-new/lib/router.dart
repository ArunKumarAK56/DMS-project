import 'package:dms_dealers/screens/about_vehicle/about_vahicle.dart';
import 'package:dms_dealers/screens/about_vehicle/about_vechicle_bloc.dart';
import 'package:dms_dealers/screens/about_vehicle/about_vechicle_event.dart';
import 'package:dms_dealers/screens/drawer/drawer.dart';
import 'package:dms_dealers/screens/login_page/login_bloc.dart';
import 'package:dms_dealers/screens/login_page/login_event.dart';
import 'package:dms_dealers/screens/login_page/login_screen.dart';
import 'package:dms_dealers/screens/notification_screen/notification_bloc.dart';
import 'package:dms_dealers/screens/notification_screen/notification_event.dart';
import 'package:dms_dealers/screens/otp_screen/otp_bloc.dart';
import 'package:dms_dealers/screens/otp_screen/otp_event.dart';
import 'package:dms_dealers/screens/otp_screen/otp_screen.dart';
import 'package:dms_dealers/screens/profile/profile_details_event.dart';
import 'package:dms_dealers/screens/profile/profile_details_screen.dart';
import 'package:dms_dealers/screens/profile_view/profile_view_bloc.dart';
import 'package:dms_dealers/screens/profile_view/profile_view_event.dart';
import 'package:dms_dealers/screens/profile_view/profile_view_screen.dart';
import 'package:dms_dealers/screens/service_details/service_details_bloc.dart';
import 'package:dms_dealers/screens/spare_details_page/spare_details_bloc.dart';
import 'package:dms_dealers/screens/spare_details_page/spare_details_event.dart';
import 'package:dms_dealers/screens/spare_details_page/spare_details_screen.dart';
import 'package:dms_dealers/screens/spare_page/model/get_spare.dart';
import 'package:dms_dealers/screens/spare_page/spare_bloc.dart';
import 'package:dms_dealers/screens/spare_page/spare_event.dart';
import 'package:dms_dealers/screens/spare_page/spare_screen.dart';
import 'package:dms_dealers/utils/color_resources.dart';
import 'package:dms_dealers/utils/perference_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'authenticatiom/bloc/authentication_bloc.dart';
import 'authenticatiom/bloc/authentication_state.dart';
import 'screens/drawer/drawer_bloc.dart';
import 'screens/drawer/drawer_event.dart';
import 'screens/notification_screen/notification_screen.dart';
import 'screens/profile/profile_details_bloc.dart';
import 'screens/service_details/service_details_event.dart';
import 'screens/service_details/service_details_screen.dart';
import 'screens/service_waranty.dart/model/get_services.dart';
import 'screens/service_waranty.dart/model/get_warranty.dart';
import 'screens/service_waranty.dart/service_warranty.dart';
import 'screens/service_waranty.dart/service_warranty_bloc.dart';
import 'screens/service_waranty.dart/service_warranty_event.dart';
import 'screens/warrent_details/warrent_details_bloc.dart';
import 'screens/warrent_details/warrent_details_event.dart';
import 'screens/warrent_details/warrent_details_screen.dart';
import 'screens/service_booking/service_booking_bloc.dart';
import 'screens/service_booking/service_booking_event.dart';
import 'screens/service_booking/service_booking_screen.dart';
class AppRoutes {
  static const String dashboardScreen = 'dashboard_screen';
  static const String loginScreen = 'login_screen';
  static const String otpScreen = 'otp_screen';
  static const String aboutVahicle = 'about_vehicle';
  static const String drawerScreen = 'drawer_screen';
  static const String serviceWarranty = 'service_warranty';
  static const String spareScreen = 'spare_screen';
  static const String spareDetailsScreen = 'spare_details_screen';
  static const String notificationScreen = 'notification_screen';
  static const String serviceDetailsScreen = 'service_details_screen';
  static const String warrentyDetailsScreen = 'warrenty_details_screen';
  static const String profile = 'profile_screen';
  static const String profile_details = 'profile_details_screen';
  static const String service_booking = 'service_booking_screen';
}

Route<dynamic>? getRoute(RouteSettings settings) {
  switch (settings.name) {
    case AppRoutes.loginScreen:
      return _buildLoginScreen();
    case AppRoutes.otpScreen:
      return _buildOtpScreen();
    case AppRoutes.aboutVahicle:
      return _buildAboutVahicleScreen();
    case AppRoutes.drawerScreen:
      return _buildDrawerScreen();
    case AppRoutes.serviceWarranty:
      return _buildServiceWarrantyScreen();
    case AppRoutes.spareScreen:
      return _buildSpareScreen();
    case AppRoutes.spareDetailsScreen:
      return _buildSpareetailsScreen(settings);
    case AppRoutes.notificationScreen:
      return _buildNotificationScreen();
    case AppRoutes.serviceDetailsScreen:
      return _buildServiceDetailsScreen(settings);
    case AppRoutes.warrentyDetailsScreen:
      return _buildWarrentyDetailsScreen(settings);
    case AppRoutes.notificationScreen:
      return _buildNotificationScreen();
    case AppRoutes.profile:
      return _buildProfileScreen();
    case AppRoutes.profile_details:
      return _buildProfileDetailsScreen();
    case AppRoutes.service_booking:
      return _buildServiceBookingScreen();
  }
  return null;
}

Route<dynamic> _buildLoginScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildLoginScreen());
}

Route<dynamic> _buildOtpScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildOtpScreen());
}

Route<dynamic> _buildAboutVahicleScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildAboutVahicle());
}

Route<dynamic> _buildDrawerScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildDrawerScreen());
}

Route<dynamic> _buildServiceWarrantyScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildServiceWarrantyScreen());
}

Route<dynamic> _buildSpareScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder._buildSpareScreen());
}

Route<dynamic> _buildSpareetailsScreen(RouteSettings settings) {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder._buildSpareDetailsScreen(settings));
}

Route<dynamic> _buildNotificationScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder._buildNotificationScreen());
}

Route<dynamic> _buildServiceDetailsScreen(RouteSettings settings) {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder._buildServiceDetailsScreen(settings));
}

Route<dynamic> _buildWarrentyDetailsScreen(RouteSettings settings) {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder._buildWarrentyDetailsScreen(settings));
}
Route<dynamic> _buildProfileScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildProfileScreen());
}

Route<dynamic> _buildProfileDetailsScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildProfileDetailsScreen());
}

Route<dynamic> _buildServiceBookingScreen() {
  return MaterialPageRoute(
      builder: (BuildContext context) => PageBuilder.buildServiceBookingScreen());
}


class PageBuilder {
  static Widget buildLoginScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
            LoginBloc()..add(LoginInitialEvent(context: context)),
        child: const LoginScreen());
  }

  static Widget buildOtpScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
            OTPBloc()..add(OTPInitialEvent(context: context)),
        child: const OTPScreen());
  }

  static Widget buildAboutVahicle() {
    return BlocProvider(
        create: (BuildContext context) =>
        AboutVehicleBloc()..add(AboutVehicleInitialEvent(context: context)),
        child: const AboutVahicle());
  }

  static Widget buildDrawerScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
        DrawerBloc()..add(DrawerInitialEvent(context: context)),
        child: DmsDrawer());
  }

  static Widget buildServiceWarrantyScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
        ServiceWarrantyBloc()..add(ServiceWarrantyInitialEvent(context: context)),
        child: ServiceWarranty());
  }


  static Widget _buildSpareScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
        SpareBloc()..add(SpareEventInitialEvent(context: context)),
        child: SpareScreen());
  }

  static Widget _buildSpareDetailsScreen(RouteSettings settings) {
    final SpareList service = settings.arguments as SpareList;

    return BlocProvider(
        create: (BuildContext context) =>
        SpareDetailsBloc()..add(SpareDetailsEventInitialEvent(context: context)),
        child: SpareDetailsScreen(spare: service));
  }

  static Widget _buildNotificationScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
        NotificationBloc()..add(NotificationEventInitialEvent(context: context)),
        child: NotificationScreen());
  }

  static Widget _buildServiceDetailsScreen(RouteSettings settings) {
    final Datum service = settings.arguments as Datum;

    return BlocProvider(
        create: (BuildContext context) =>
        ServiceDetailsBloc()..add(ServiceDetailsEventInitialEvent(context: context)),
        child: ServiceDetailsScreen(service: service));
  }

  static Widget _buildWarrentyDetailsScreen(RouteSettings settings) {
    final WarrantyList warranty = settings.arguments as WarrantyList;

    return BlocProvider(
        create: (BuildContext context) =>
        WarrentDetailsBloc()..add(WarrentDetailsEventInitialEvent(context: context)),
        child: WarrentDetailsScreen(warranty : warranty));
  }

  static Widget buildProfileScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
        ProfileDetailsBloc()..add(ProfileDetailsEventInitialEvent(context: context)),
        child: const ProfileDetailsScreen());
  }

  static Widget buildProfileDetailsScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
        ProfileViewBloc()..add(ProfileViewEventInitialEvent(context: context)),
        child: const ProfileView());
  }


  static Widget buildServiceBookingScreen() {
    return BlocProvider(
        create: (BuildContext context) =>
        ServiceBookingBloc()..add(ServiceBookingEventInitialEvent(context: context)),
        child: ServiceBookingScreen());
  }
}



Widget addAuthBloc(BuildContext context, Widget widget) {
  return BlocListener(
    bloc: BlocProvider.of<AuthenticationBloc>(context),
    listener: (BuildContext context, Object? state) async {
      if (state is AuthenticationUnAuthenticated) {
        while (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
        await Navigator.pushReplacementNamed(context, AppRoutes.loginScreen);
      }

      if (state is AuthenticationAuthenticated) {
        while (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
        await Navigator.pushReplacementNamed(context, AppRoutes.aboutVahicle);
      }
    },
    child: BlocBuilder(
      bloc: BlocProvider.of<AuthenticationBloc>(context),
      builder: (BuildContext context, Object? state) {
        if (state is NoInternetConnectionState) {
          return Card(
            child: Container(
              height: MediaQuery.of(context).size.height / 3,
              width: MediaQuery.of(context).size.width / 1,
              decoration: const BoxDecoration(
                color: Colors.white,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.no_accounts_sharp,
                    size: 34,
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Text('No Internet Connection',
                      ),
                ],
              ),
            ),
          );
        } else {
          return widget;
        }
      },
    ),
  );
}
