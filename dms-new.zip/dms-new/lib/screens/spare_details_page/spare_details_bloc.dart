import 'package:dms_dealers/screens/spare_details_page/spare_details_event.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../base/base_state.dart';


class SpareDetailsBloc extends Bloc<SpareDetailsEvent, BaseState> {
  SpareDetailsBloc() : super(InitialState());


  @override
  Stream<BaseState> mapEventToState(
      SpareDetailsEvent event,
      ) async* {
    if (event is SpareDetailsEventInitialEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }
  }
}