
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class SpareDetailsEvent extends BaseEquatable {}

class SpareDetailsEventInitialEvent extends SpareDetailsEvent {
  BuildContext? context;
  dynamic arguments;

  SpareDetailsEventInitialEvent({this.context});

}
