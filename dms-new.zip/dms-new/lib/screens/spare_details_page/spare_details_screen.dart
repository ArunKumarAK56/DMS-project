import 'package:dms_dealers/screens/spare_details_page/spare_details_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../base/base_state.dart';
import '../spare_page/model/get_spare.dart';

class SpareDetailsScreen extends StatefulWidget {
  final SpareList spare;

  const SpareDetailsScreen({Key? key, required this.spare}) : super(key: key);

  @override
  _SpareScreenState createState() => _SpareScreenState();
}

class _SpareScreenState extends State<SpareDetailsScreen> {
  late SpareDetailsBloc bloc;

  @override
  void initState() {
    bloc = BlocProvider.of<SpareDetailsBloc>(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener(
        bloc: bloc,
        listener: (BuildContext context, BaseState state) async {},
        child: BlocBuilder(
            bloc: bloc,
            builder: (BuildContext context, BaseState state) {
              if (state is InitialState) {
                return const Center(
                  child: Text('New'),
                );
              } else if (state is SuccessState) {

              }
              return SafeArea(
                  child: Scaffold(
                    backgroundColor: Colors.white70,
                    appBar: AppBar(
                      leading:GestureDetector(
                        onTap: (){
                          Navigator.pop(context);
                        },
                        child: const Icon(Icons.arrow_back_ios),
                      ),
                      title: const Center(child: Text('SpareDetails', style:TextStyle(fontSize: 25.0, color: Colors.black,fontFamily: 'Poppins'),)),
                    ),
                      body:  Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                              children: [
                                Card(
                                  //   elevation: 50,
                                  shadowColor: Colors.black,
                                  color: Colors.white,
                                  child:Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                         Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text('${widget.spare.spareName}', style:TextStyle(fontSize: 20.0, color: Colors.black,fontFamily: 'Poppins'),),
                                            Text('${widget.spare.price}', style:TextStyle(fontSize: 15.0, color: Colors.grey,fontFamily: 'Poppins'),)
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            Container(
                                              width: 10,
                                              height: 50,
                                              decoration: const BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.amber,
                                              ),
                                            ),
                                            const SizedBox(width: 5,),
                                             Text('${widget.spare.invoiceDetails.status}', style:TextStyle(fontSize: 15.0, color: Colors.black,fontFamily: 'Poppins'),),
                                            const Spacer(),
                                             Text('${widget.spare.stockDetails.company}', style:TextStyle(fontSize: 15.0, color: Colors.grey,fontFamily: 'Poppins'),)
                                          ],
                                        ),
                                        const SizedBox(height:20,),
                                        const Text('Dealer identified the issues', style:TextStyle(fontSize: 16.0, color: Colors.black,fontFamily: 'Poppins'),),
                                        const Divider(),
                                        const SizedBox(height:10,),
                                        const Text('Remarks -1', style:TextStyle(fontSize: 15.0, color: Colors.grey,fontFamily: 'Poppins'),),
                                        const SizedBox(height:10,),
                                        const Text('This property takes in Color class as the object to assign a color to the shadow,', style:TextStyle(fontSize: 15.0, color: Colors.black,fontFamily: 'Poppins'),),
                                        const SizedBox(height:10,),
                                        Row(
                                          children: [
                                            Spacer(),
                                            ElevatedButton(
                                              style: ElevatedButton.styleFrom(  backgroundColor: Colors.white

                                              ),
                                              child:const Text('Rejected', style:TextStyle(fontSize: 16.0, color: Colors.black,fontFamily: 'Poppins'),),
                                              onPressed: () {},
                                            ),
                                            const SizedBox(width: 5,),
                                            ElevatedButton(
                                              style: ElevatedButton.styleFrom(  backgroundColor: Colors.blue

                                              ),
                                              child:const Text('Accept & Resolve', style:TextStyle(fontSize: 16.0, color: Colors.black,fontFamily: 'Poppins'),),
                                              onPressed: () {},
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(height: 10,),
                                ListView.builder(
                                    itemCount: 2,
                                    shrinkWrap: true,
                                    itemBuilder: (BuildContext context, int index) {
                                      return   const Card(
                                        //   elevation: 50,
                                        shadowColor: Colors.black,
                                        color: Colors.white,
                                        child:Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text('Low Battery', style:TextStyle(fontSize: 16.0, color: Colors.black,fontFamily: 'Poppins'),),
                                                  Text('2 hrs ago', style:TextStyle(fontSize: 15.0, color: Colors.grey,fontFamily: 'Poppins'),)
                                                ],
                                              ),
                                              SizedBox(height:20,),
                                              Text('Dealer identified the issues', style:TextStyle(fontSize: 16.0, color: Colors.black,fontFamily: 'Poppins'),),
                                            ],
                                          ),
                                        ),
                                      );
                                    }),
                              ]))
              ));
            }));
  }
}