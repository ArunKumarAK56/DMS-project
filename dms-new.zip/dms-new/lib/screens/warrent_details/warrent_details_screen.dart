import 'package:dms_dealers/screens/service_details/service_details_bloc.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_warranty.dart';
import 'package:dms_dealers/screens/spare_details_page/spare_details_bloc.dart';
import 'package:dms_dealers/screens/warrent_details/warrent_details_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../base/base_state.dart';
import 'package:intl/intl.dart';

class WarrentDetailsScreen extends StatefulWidget {
  final WarrantyList warranty;

  const WarrentDetailsScreen({Key? key, required this.warranty}) : super(key: key);

  @override
  _WarrentScreenState createState() => _WarrentScreenState();
}

class _WarrentScreenState extends State<WarrentDetailsScreen> {
  late WarrentDetailsBloc bloc;

  @override
  void initState() {
    bloc = BlocProvider.of<WarrentDetailsBloc>(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener(
      bloc: bloc,
      listener: (BuildContext context, BaseState state) async {},
      child: BlocBuilder(
        bloc: bloc,
        builder: (BuildContext context, BaseState state) {
          if (state is InitialState) {
            return const Center(
              child: Text('New'),
            );
          } else if (state is SuccessState) {
            // Handle SuccessState if needed
          }

          return SafeArea(
            child: Scaffold(
              appBar: AppBar(
                title: Text('Warrenty Details'),
                leading: IconButton(
                  icon: Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ),
              body: Padding(
                padding: const EdgeInsets.all(16.0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildWarrantyInfoCard(),
                      SizedBox(height: 16),
                      _buildStatusCard(),
                      SizedBox(height: 16),
                      _buildWarrantyCard(),
                      SizedBox(height: 16),
                      _buildUploadProofCard(),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildWarrantyInfoCard() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [BoxShadow(color: Colors.grey.shade200, blurRadius: 4)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${widget.warranty.item}',
                style: const TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'S-ID ${widget.warranty.warrantyId}, ${getFormattedDate("${widget.warranty.createdAt}")}',
                style: const TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
          Row(
            children: [
              Icon(
                Icons.circle,
                color: widget.warranty.inspectionReport == 'Completed'
                    ? Colors.green
                    : Colors.red,
                size: 12,
              ),
              const SizedBox(width: 4),
              Text(
                widget.warranty.inspectionReport!,
                style: const TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [BoxShadow(color: Colors.grey.shade200, blurRadius: 4)],
      ),
      child: ExpansionTile(
        title: Text(
          'Status',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        children: [
          TimelineTile(
            isFirst: true,
            isLast: false,
            isActive: true,
            title: 'Claim Verified',
            subtitle: 'Verified on : Thu, 27th Jul',
          ),
          TimelineTile(
            isFirst: false,
            isLast: false,
            isActive: true,
            title: 'In Transit',
          ),
          TimelineTile(
            isFirst: false,
            isLast: false,
            isActive: false,
            title: 'Inspection',
          ),
          TimelineTile(
            isFirst: false,
            isLast: false,
            isActive: false,
            title: 'Under Service/Replacement',
          ),
          TimelineTile(
            isFirst: false,
            isLast: false,
            isActive: false,
            title: 'Returning',
          ),
          TimelineTile(
            isFirst: false,
            isLast: true,
            isActive: false,
            title: 'Dealer Received',
          ),
        ],
      ),
    );
  }

  Widget _buildWarrantyCard() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [BoxShadow(color: Colors.grey.shade200, blurRadius: 4)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Warranty Card',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WarrantyDetailItem(
                label: 'Selected Item',
                value: '${widget.warranty.item}',
              ),
              WarrantyDetailItem(
                label: 'Item Brand',
                value: '${widget.warranty.itemBrand}',
              ),
            ],
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WarrantyDetailItem(
                label: 'Item No.',
                value: '${widget.warranty.itemNo}',
              ),
              WarrantyDetailItem(
                label: 'Capacity',
                value: '${widget.warranty.capacity}',
              ),
            ],
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              WarrantyDetailItem(
                label: 'Warranty Period',
                value: '${getFormattedDate(widget.warranty.claimVerificationDate)}',
              ),
              WarrantyDetailItem(
                label: 'Still Warranty',
                value: '${getFormattedDate(widget.warranty.stillWarranty)}',
              ),
            ],
          ),
          SizedBox(height: 16),
          Text(
            'Remarks',
            style: TextStyle(color: Colors.grey),
          ),
          SizedBox(height: 4),
          Text(
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque ut nunc erat.',
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildUploadProofCard() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [BoxShadow(color: Colors.grey.shade200, blurRadius: 4)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Upload Proof',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          Image.network(
            '${widget.warranty.fileUrl}', // replace with your proof image asset
            height: 150,
          ),
          SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                Image.network(
                  '${widget.warranty.inTransitDetails?.file}', // replace with your proof image asset
                  height: 100,
                ),
                SizedBox(width: 8),
                Image.network(
                  '${widget.warranty.returnTransitDetails?.file}', // replace with your proof image asset
                  height: 100,
                ),
                SizedBox(width: 8),
                // Add more images if needed
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TimelineTile extends StatelessWidget {
  final bool isFirst;
  final bool isLast;
  final bool isActive;
  final String title;
  final String? subtitle;

  const TimelineTile({
    required this.isFirst,
    required this.isLast,
    required this.isActive,
    required this.title,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            if (!isFirst)
              Container(
                width: 2,
                height: 20,
                color: isActive ? Colors.green : Colors.grey,
              ),
            CircleAvatar(
              radius: 10,
              backgroundColor: isActive ? Colors.green : Colors.grey,
              child: isActive
                  ? Icon(Icons.check, color: Colors.white, size: 14)
                  : SizedBox(),
            ),
            if (!isLast)
              Container(
                width: 2,
                height: 20,
                color: isActive ? Colors.green : Colors.grey,
              ),
          ],
        ),
        SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: isActive ? Colors.black : Colors.grey,
                ),
              ),
              if (subtitle != null)
                Text(
                  subtitle!,
                  style: TextStyle(
                    fontSize: 12,
                    color: isActive ? Colors.black : Colors.grey,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class WarrantyDetailItem extends StatelessWidget {
  final String label;
  final String value;

  const WarrantyDetailItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(color: Colors.grey),
        ),
        SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

String getFormattedDate(String dateStr) {
  // Parse the date string to a DateTime object
  DateTime parsedDate = DateTime.parse(dateStr);
  // Format the DateTime object to get the date part
  String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

  return formattedDate;
}
