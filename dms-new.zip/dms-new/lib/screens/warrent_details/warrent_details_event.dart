
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class WarrentDetailsEvent extends BaseEquatable {}

class WarrentDetailsEventInitialEvent extends WarrentDetailsEvent {
  BuildContext? context;
  dynamic arguments;

  WarrentDetailsEventInitialEvent({this.context});
}
