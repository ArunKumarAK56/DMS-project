import 'package:dms_dealers/screens/service_details/service_details_event.dart';
import 'package:dms_dealers/screens/warrent_details/warrent_details_event.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../base/base_state.dart';


class WarrentDetailsBloc extends Bloc<WarrentDetailsEvent, BaseState> {
  WarrentDetailsBloc() : super(InitialState());


  @override
  Stream<BaseState> mapEventToState(
      WarrentDetailsEvent event,
      ) async* {
    if (event is WarrentDetailsEventInitialEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }
  }
}