import 'dart:convert';

GetVechicle getVechicleFromJson(String str) => GetVechicle.fromJson(json.decode(str));

String getVechicleToJson(GetVechicle data) => json.encode(data.toJson());

class GetVechicle {
  List<Vechicle> data;
  String status;

  GetVechicle({
    required this.data,
    required this.status,
  });

  factory GetVechicle.fromJson(Map<String, dynamic> json) => GetVechicle(
    data: List<Vechicle>.from(json["data"].map((x) => Vechicle.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "status": status,
  };
}

class Vechicle {
  String invoiceId;
  String chasisNo;
  String productName;

  Vechicle({
    required this.invoiceId,
    required this.chasisNo,
    required this.productName,
  });

  factory Vechicle.fromJson(Map<String, dynamic> json) => Vechicle(
    invoiceId: json["invoice_id"],
    chasisNo: json["chasis_no"],
    productName: json["product_name"],
  );

  Map<String, dynamic> toJson() => {
    "invoice_id": invoiceId,
    "chasis_no": chasisNo,
    "product_name": productName,
  };
}
