class Vehicle {
  final String invoiceId;
  final String chasisNo;
  final String productName;

  Vehicle({required this.invoiceId, required this.chasisNo, required this.productName});

  factory Vehicle.fromJson(Map<String, dynamic> json) {
    return Vehicle(
      invoiceId: json['invoice_id'],
      chasisNo: json['chasis_no'],
      productName: json['product_name'],
    );
  }
}