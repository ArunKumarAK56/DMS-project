import 'dart:convert';
GetVechicleDetails getVechicleDetailsFromJson(String str) => GetVechicleDetails.fromJson(json.decode(str));

String getVechicleDetailsToJson(GetVechicleDetails data) => json.encode(data.toJson());

class GetVechicleDetails {
  Data data;
  String status;

  GetVechicleDetails({
    required this.data,
    required this.status,
  });

  factory GetVechicleDetails.fromJson(Map<String, dynamic> json) => GetVechicleDetails(
    data: Data.fromJson(json["data"]),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": data.toJson(),
    "status": status,
  };
}

class Data {
  InvoiceDetails invoiceDetails;
  VehicleDetails vehicleDetails;
  int warranty;
  int services;

  Data({
    required this.invoiceDetails,
    required this.vehicleDetails,
    required this.warranty,
    required this.services,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    invoiceDetails: InvoiceDetails.fromJson(json["invoice_details"]),
    vehicleDetails: VehicleDetails.fromJson(json["vehicle_details"]),
    warranty: json["warranty"],
    services: json["services"],
  );

  Map<String, dynamic> toJson() => {
    "invoice_details": invoiceDetails.toJson(),
    "vehicle_details": vehicleDetails.toJson(),
    "warranty": warranty,
    "services": services,
  };
}

class InvoiceDetails {
  int id;
  String dealerId;
  String invoiceId;
  int customerId;
  String customerName;
  DateTime invoiceDate;
  DateTime dueDate;
  String termsConditions;
  String fileUrl;
  int subTotal;
  int sgst;
  int cgst;
  int igst;
  int discount;
  String status;
  int total;
  String pendingPayments;
  String invoiceType;
  DateTime createdAt;
  DateTime updatedAt;

  InvoiceDetails({
    required this.id,
    required this.dealerId,
    required this.invoiceId,
    required this.customerId,
    required this.customerName,
    required this.invoiceDate,
    required this.dueDate,
    required this.termsConditions,
    required this.fileUrl,
    required this.subTotal,
    required this.sgst,
    required this.cgst,
    required this.igst,
    required this.discount,
    required this.status,
    required this.total,
    required this.pendingPayments,
    required this.invoiceType,
    required this.createdAt,
    required this.updatedAt,
  });

  factory InvoiceDetails.fromJson(Map<String, dynamic> json) => InvoiceDetails(
    id: json["id"],
    dealerId: json["dealer_id"],
    invoiceId: json["invoice_id"],
    customerId: json["customer_id"],
    customerName: json["customer_name"],
    invoiceDate: DateTime.parse(json["invoice_date"]),
    dueDate: DateTime.parse(json["due_date"]),
    termsConditions: json["terms_conditions"],
    fileUrl: json["file_url"],
    subTotal: json["sub_total"],
    sgst: json["sgst"],
    cgst: json["cgst"],
    igst: json["igst"],
    discount: json["discount"],
    status: json["status"],
    total: json["total"],
    pendingPayments: json["pending_payments"],
    invoiceType: json["invoice_type"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "dealer_id": dealerId,
    "invoice_id": invoiceId,
    "customer_id": customerId,
    "customer_name": customerName,
    "invoice_date": "${invoiceDate.year.toString().padLeft(4, '0')}-${invoiceDate.month.toString().padLeft(2, '0')}-${invoiceDate.day.toString().padLeft(2, '0')}",
    "due_date": "${dueDate.year.toString().padLeft(4, '0')}-${dueDate.month.toString().padLeft(2, '0')}-${dueDate.day.toString().padLeft(2, '0')}",
    "terms_conditions": termsConditions,
    "file_url": fileUrl,
    "sub_total": subTotal,
    "sgst": sgst,
    "cgst": cgst,
    "igst": igst,
    "discount": discount,
    "status": status,
    "total": total,
    "pending_payments": pendingPayments,
    "invoice_type": invoiceType,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class VehicleDetails {
  int id;
  String dealerId;
  Vehicle vehicle;
  Variant variant;
  Stock stock;
  DateTime createdAt;
  DateTime updatedAt;
  String productType;

  VehicleDetails({
    required this.id,
    required this.dealerId,
    required this.vehicle,
    required this.variant,
    required this.stock,
    required this.createdAt,
    required this.updatedAt,
    required this.productType,
  });

  factory VehicleDetails.fromJson(Map<String, dynamic> json) => VehicleDetails(
    id: json["id"],
    dealerId: json["dealer_id"],
    vehicle: Vehicle.fromJson(json["vehicle"]),
    variant: Variant.fromJson(json["variant"]),
    stock: Stock.fromJson(json["stock"]),
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    productType: json["product_type"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "dealer_id": dealerId,
    "vehicle": vehicle.toJson(),
    "variant": variant.toJson(),
    "stock": stock.toJson(),
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "product_type": productType,
  };
}

class Stock {
  int id;
  int vechileStocksId;
  String chasisNo;
  DateTime mftDate;
  String color;
  String motorNo;
  String batteryNo;
  String convertorNo;
  String keyNo;
  String controllerNo;
  String meterNo;
  DateTime createdAt;
  DateTime updatedAt;

  Stock({
    required this.id,
    required this.vechileStocksId,
    required this.chasisNo,
    required this.mftDate,
    required this.color,
    required this.motorNo,
    required this.batteryNo,
    required this.convertorNo,
    required this.keyNo,
    required this.controllerNo,
    required this.meterNo,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Stock.fromJson(Map<String, dynamic> json) => Stock(
    id: json["id"],
    vechileStocksId: json["vechile_stocks_id"],
    chasisNo: json["chasis_no"],
    mftDate: DateTime.parse(json["mft_date"]),
    color: json["color"],
    motorNo: json["motor_no"],
    batteryNo: json["battery_no"],
    convertorNo: json["convertor_no"],
    keyNo: json["key_no"],
    controllerNo: json["controller_no"],
    meterNo: json["meter_no"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "vechile_stocks_id": vechileStocksId,
    "chasis_no": chasisNo,
    "mft_date": "${mftDate.year.toString().padLeft(4, '0')}-${mftDate.month.toString().padLeft(2, '0')}-${mftDate.day.toString().padLeft(2, '0')}",
    "color": color,
    "motor_no": motorNo,
    "battery_no": batteryNo,
    "convertor_no": convertorNo,
    "key_no": keyNo,
    "controller_no": controllerNo,
    "meter_no": meterNo,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class Variant {
  int id;
  int vehicleId;
  String variantName;
  DateTime releasedDate;
  String subsidy;
  String motorName;
  String motorType;
  String motorVoltage;
  String motorCapacity;
  String motorWarrantyKm;
  String motorWarrantyMonths;
  String motorWarrantyType;
  String batteryName;
  String batteryType;
  String batteryLifecycle;
  String batteryCapacity;
  String batteryWarrantyKm;
  String batteryWarrantyMonths;
  String batteryWarrantyType;
  String chargerName;
  String chargerCapacity;
  String chargerType;
  String chargerWarrantyKm;
  String chargerWarrantyMonths;
  String chargerWarrantyType;
  String converterName;
  String converterCapacity;
  String converterWarrantyKm;
  String converterWarrantyMonths;
  String converterWarrantyType;
  String controllerName;
  String controllerCapacity;
  String controllerWarrantyKm;
  String controllerWarrantyMonths;
  String controllerWarrantyType;
  String displayName;
  String displayType;
  String displayWarrantyKm;
  String displayWarrantyMonths;
  String displayWarrantyType;
  String colorDetails;
  String otherDetails;
  String priceGroups;
  DateTime createdAt;
  DateTime updatedAt;

  Variant({
    required this.id,
    required this.vehicleId,
    required this.variantName,
    required this.releasedDate,
    required this.subsidy,
    required this.motorName,
    required this.motorType,
    required this.motorVoltage,
    required this.motorCapacity,
    required this.motorWarrantyKm,
    required this.motorWarrantyMonths,
    required this.motorWarrantyType,
    required this.batteryName,
    required this.batteryType,
    required this.batteryLifecycle,
    required this.batteryCapacity,
    required this.batteryWarrantyKm,
    required this.batteryWarrantyMonths,
    required this.batteryWarrantyType,
    required this.chargerName,
    required this.chargerCapacity,
    required this.chargerType,
    required this.chargerWarrantyKm,
    required this.chargerWarrantyMonths,
    required this.chargerWarrantyType,
    required this.converterName,
    required this.converterCapacity,
    required this.converterWarrantyKm,
    required this.converterWarrantyMonths,
    required this.converterWarrantyType,
    required this.controllerName,
    required this.controllerCapacity,
    required this.controllerWarrantyKm,
    required this.controllerWarrantyMonths,
    required this.controllerWarrantyType,
    required this.displayName,
    required this.displayType,
    required this.displayWarrantyKm,
    required this.displayWarrantyMonths,
    required this.displayWarrantyType,
    required this.colorDetails,
    required this.otherDetails,
    required this.priceGroups,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Variant.fromJson(Map<String, dynamic> json) => Variant(
    id: json["id"],
    vehicleId: json["vehicle_id"],
    variantName: json["variant_name"],
    releasedDate: DateTime.parse(json["released_date"]),
    subsidy: json["subsidy"],
    motorName: json["motor_name"],
    motorType: json["motor_type"],
    motorVoltage: json["motor_voltage"],
    motorCapacity: json["motor_capacity"],
    motorWarrantyKm: json["motor_warranty_km"],
    motorWarrantyMonths: json["motor_warranty_months"],
    motorWarrantyType: json["motor_warranty_type"],
    batteryName: json["battery_name"],
    batteryType: json["battery_type"],
    batteryLifecycle: json["battery_lifecycle"],
    batteryCapacity: json["battery_capacity"],
    batteryWarrantyKm: json["battery_warranty_km"],
    batteryWarrantyMonths: json["battery_warranty_months"],
    batteryWarrantyType: json["battery_warranty_type"],
    chargerName: json["charger_name"],
    chargerCapacity: json["charger_capacity"],
    chargerType: json["charger_type"],
    chargerWarrantyKm: json["charger_warranty_km"],
    chargerWarrantyMonths: json["charger_warranty_months"],
    chargerWarrantyType: json["charger_warranty_type"],
    converterName: json["converter_name"],
    converterCapacity: json["converter_capacity"],
    converterWarrantyKm: json["converter_warranty_km"],
    converterWarrantyMonths: json["converter_warranty_months"],
    converterWarrantyType: json["converter_warranty_type"],
    controllerName: json["controller_name"],
    controllerCapacity: json["controller_capacity"],
    controllerWarrantyKm: json["controller_warranty_km"],
    controllerWarrantyMonths: json["controller_warranty_months"],
    controllerWarrantyType: json["controller_warranty_type"],
    displayName: json["display_name"],
    displayType: json["display_type"],
    displayWarrantyKm: json["display_warranty_km"],
    displayWarrantyMonths: json["display_warranty_months"],
    displayWarrantyType: json["display_warranty_type"],
    colorDetails: json["color_details"],
    otherDetails: json["other_details"],
    priceGroups: json["price_groups"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "vehicle_id": vehicleId,
    "variant_name": variantName,
    "released_date": "${releasedDate.year.toString().padLeft(4, '0')}-${releasedDate.month.toString().padLeft(2, '0')}-${releasedDate.day.toString().padLeft(2, '0')}",
    "subsidy": subsidy,
    "motor_name": motorName,
    "motor_type": motorType,
    "motor_voltage": motorVoltage,
    "motor_capacity": motorCapacity,
    "motor_warranty_km": motorWarrantyKm,
    "motor_warranty_months": motorWarrantyMonths,
    "motor_warranty_type": motorWarrantyType,
    "battery_name": batteryName,
    "battery_type": batteryType,
    "battery_lifecycle": batteryLifecycle,
    "battery_capacity": batteryCapacity,
    "battery_warranty_km": batteryWarrantyKm,
    "battery_warranty_months": batteryWarrantyMonths,
    "battery_warranty_type": batteryWarrantyType,
    "charger_name": chargerName,
    "charger_capacity": chargerCapacity,
    "charger_type": chargerType,
    "charger_warranty_km": chargerWarrantyKm,
    "charger_warranty_months": chargerWarrantyMonths,
    "charger_warranty_type": chargerWarrantyType,
    "converter_name": converterName,
    "converter_capacity": converterCapacity,
    "converter_warranty_km": converterWarrantyKm,
    "converter_warranty_months": converterWarrantyMonths,
    "converter_warranty_type": converterWarrantyType,
    "controller_name": controllerName,
    "controller_capacity": controllerCapacity,
    "controller_warranty_km": controllerWarrantyKm,
    "controller_warranty_months": controllerWarrantyMonths,
    "controller_warranty_type": controllerWarrantyType,
    "display_name": displayName,
    "display_type": displayType,
    "display_warranty_km": displayWarrantyKm,
    "display_warranty_months": displayWarrantyMonths,
    "display_warranty_type": displayWarrantyType,
    "color_details": colorDetails,
    "other_details": otherDetails,
    "price_groups": priceGroups,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class Vehicle {
  int id;
  String oemId;
  String productType;
  String productName;
  String productImg;
  String type;
  String registration;
  int hsnNo;
  int mftYear;
  int cgst;
  int sgst;
  int igst;
  DateTime createdAt;
  DateTime updatedAt;

  Vehicle({
    required this.id,
    required this.oemId,
    required this.productType,
    required this.productName,
    required this.productImg,
    required this.type,
    required this.registration,
    required this.hsnNo,
    required this.mftYear,
    required this.cgst,
    required this.sgst,
    required this.igst,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Vehicle.fromJson(Map<String, dynamic> json) => Vehicle(
    id: json["id"],
    oemId: json["oem_id"],
    productType: json["product_type"],
    productName: json["product_name"],
    productImg: json["product_img"],
    type: json["type"],
    registration: json["registration"],
    hsnNo: json["hsn_no"],
    mftYear: json["mft_year"],
    cgst: json["cgst"],
    sgst: json["sgst"],
    igst: json["igst"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "oem_id": oemId,
    "product_type": productType,
    "product_name": productName,
    "product_img": productImg,
    "type": type,
    "registration": registration,
    "hsn_no": hsnNo,
    "mft_year": mftYear,
    "cgst": cgst,
    "sgst": sgst,
    "igst": igst,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}
