
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class AboutVehicleEvent extends BaseEquatable {}

class AboutVehicleInitialEvent extends AboutVehicleEvent {
  BuildContext? context;
  dynamic arguments;

  AboutVehicleInitialEvent({this.context});

}

class GetVehicleEvent extends AboutVehicleEvent {
  GetVehicleEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}


class GetVehicleDetailsEvent extends AboutVehicleEvent {
  GetVehicleDetailsEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}