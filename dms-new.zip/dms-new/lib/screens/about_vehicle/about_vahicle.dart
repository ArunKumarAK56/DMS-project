import 'package:dms_dealers/base/base_state.dart';
import 'package:dms_dealers/screens/about_vehicle/about_vechicle_bloc.dart';
import 'package:dms_dealers/screens/about_vehicle/about_vechicle_event.dart';
import 'package:dms_dealers/screens/about_vehicle/model/get_vehicle.dart';
import 'package:dms_dealers/screens/about_vehicle/model/get_vehicle_details.dart';
import 'package:dms_dealers/screens/drawer/drawer.dart';
import 'package:dms_dealers/screens/drawer/drawer_bloc.dart';
import 'package:dms_dealers/screens/drawer/drawer_event.dart';
import 'package:dms_dealers/utils/contants.dart';
import 'package:dms_dealers/utils/image_resources.dart';
import 'package:dms_dealers/utils/singleton.dart';
import 'package:dms_dealers/widgets/basic_info_card.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../utils/color_resources.dart';
import '../../widgets/main_menu_card.dart';

class AboutVahicle extends StatefulWidget {
  const AboutVahicle({super.key});

  @override
  State<AboutVahicle> createState() => _AboutVahicleState();
}

class _AboutVahicleState extends State<AboutVahicle> {
  late AboutVehicleBloc bloc;

  List<Vechicle> _items = [];
  Vechicle? _selectedItem;
  bool _isLoading = true;

  String? vehicleName = "";
  String? vehicleImage = "";
  String? chasisNo = "";
  String? NoofServices = "";
  String? NoofWarrantyClain = "";
  String? InvoiceId = "";
  String? InvoiceData = "";
  String? Status = "";
  String? ModelName = "";
  String? ModelVarient = "";
  String? MFTyear = "";
  String? ColorType = "";
  String? Subsity = "";
  String? HSNcode = "";
  String? MotorNo = "";
  String? Motor = "";
  String? MotorType = "";
  String? MotorRange = "";
  String? Warranty = "";
  String? ExpirayAt = "";

  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of<AboutVehicleBloc>(context);
    bloc.add(GetVehicleEvent(context: context, arguments: FlashSingleton.instance.id));
  }

  String getFormattedDate(String dateStr) {
    // Parse the date string to a DateTime object
    DateTime parsedDate = DateTime.parse(dateStr);
    // Format the DateTime object to get the date part
    String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

    return formattedDate;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocListener(
        bloc: bloc,
        listener: (BuildContext context, BaseState state) async {},
        child: BlocBuilder(
            bloc: bloc,
            builder: (BuildContext context, BaseState state) {
              if (state is InitialState) {
                return const Center(
                  child: Text('Loading state'),
                );
              } else if (state is SuccessState) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (state.successResponse is GetVechicle) {
                    final GetVechicle response = state.successResponse;
                    if (response.status == Constants.success) {
                      setState(() {
                        _items = response.data;
                        _isLoading = false;

                        if (_items.isNotEmpty) {
                          // Select the first vehicle and fetch its details
                          _selectedItem = _items[0];
                          String invoiceId = _selectedItem!.invoiceId;
                          String chasisNo = _selectedItem!.chasisNo;
                          bloc.add(GetVehicleDetailsEvent(context: context, arguments: {
                            'invoice_id': invoiceId,
                            'chasis_no': chasisNo,
                          }));
                        }
                      });
                    }
                  } else if (state.successResponse is GetVechicleDetails) {
                    final GetVechicleDetails response = state.successResponse;
                    if (response.status == Constants.success) {
                      setState(() {
                        vehicleName = response.data.vehicleDetails.vehicle.productName;
                        vehicleImage = response.data.vehicleDetails.vehicle.productImg;
                        chasisNo = response.data.vehicleDetails.stock.chasisNo;
                        NoofServices = "${response.data.services}";
                        NoofWarrantyClain = "${response.data.warranty}";
                        InvoiceId = response.data.invoiceDetails.invoiceId;
                        InvoiceData = "${response.data.invoiceDetails.invoiceDate}";
                        Status = response.data.invoiceDetails.status;
                        ModelName = response.data.vehicleDetails.variant.motorName;
                        ModelVarient = response.data.vehicleDetails.variant.variantName;
                        MFTyear = "${response.data.vehicleDetails.vehicle.mftYear}";
                        ColorType = response.data.vehicleDetails.stock.color;
                        Subsity = response.data.vehicleDetails.variant.subsidy;
                        HSNcode = "${response.data.vehicleDetails.vehicle.hsnNo}";
                        MotorNo = response.data.vehicleDetails.stock.motorNo;
                        Motor = response.data.vehicleDetails.variant.motorName;
                        MotorType = response.data.vehicleDetails.variant.motorType;
                        MotorRange = response.data.vehicleDetails.variant.motorCapacity;
                        Warranty = response.data.vehicleDetails.variant.motorWarrantyMonths;
                        ExpirayAt = "${response.data.vehicleDetails.variant.releasedDate}";
                      });
                    }
                  }
                });
              }

              return Scaffold(
                appBar: AppBar(
                  automaticallyImplyLeading: false,
                  title: const Text(
                    'About Vehicle',
                    style: TextStyle(
                      fontFamily: 'Poppins-Medium',
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: ColorResource.loginPara
                    ),
                  ),
                  actions: [
                    const Padding(
                      padding: EdgeInsets.only(right: 10.0),
                      child: Icon(Icons.notification_add),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 10.0),
                      child: Builder(
                        builder: (context) => InkWell(
                          onTap: () {
                            Scaffold.of(context).openDrawer();
                          },
                          child: const Icon(Icons.menu),
                        ),
                      ),
                    ),
                  ],
                ),
                drawer: Drawer(
                  width: MediaQuery.of(context).size.width * 0.85,
                  child: BlocProvider(
                    create: (BuildContext context) => DrawerBloc()..add(DrawerInitialEvent(context: context)),
                    child: DmsDrawer(),
                  ),
                ),
                body: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          alignment: Alignment.topLeft,
                          child: _isLoading
                              ? CircularProgressIndicator()
                              : DropdownButton<Vechicle>(
                            hint: Text('Select Vehicle'),
                            value: _selectedItem,
                            onChanged: (Vechicle? newValue) {
                              if (newValue != null) {
                                String invoiceId = newValue.invoiceId;
                                String chasisNo = newValue.chasisNo;
                                bloc.add(GetVehicleDetailsEvent(context: context, arguments: {
                                  'invoice_id': invoiceId,
                                  'chasis_no': chasisNo,
                                }));
                                setState(() {
                                  _selectedItem = newValue;
                                });
                              }
                            },
                            items: _items.map((Vechicle vehicle) {
                              return DropdownMenuItem<Vechicle>(
                                value: vehicle,
                                child: Text(vehicle.productName),
                              );
                            }).toList(),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: ColorResource.lightGrey2, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: MainMenuCard(
                            img: vehicleImage!,
                            title: vehicleName == "" ? 'N/A' : vehicleName!,
                            subTitle: chasisNo == "" ? 'N/A' : chasisNo!,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          alignment: WrapAlignment.center,
                          runSpacing: 16,
                          spacing: 16,
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width / 2.3,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(color: ColorResource.lightGrey2),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Row(
                                  children: [
                                    Image.asset(ImageResource.build),
                                    const SizedBox(width: 10),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          NoofServices == "" ? 'N/A' : NoofServices!,
                                          style: const TextStyle(
                                            fontFamily: 'Poppins',
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black,
                                          ),
                                        ),
                                        const Text(
                                          'No of services',
                                          style: TextStyle(
                                            fontFamily: 'Poppins-Regular',
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width / 2.3,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(color: ColorResource.lightGrey2),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Row(
                                  children: [
                                    Image.asset(ImageResource.warranty),
                                    const SizedBox(width: 10),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          NoofWarrantyClain == "" ? 'N/A' : NoofWarrantyClain!,
                                          style: const TextStyle(
                                            fontFamily: 'Poppins-Regular',
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black,
                                          ),
                                        ),
                                        const Text(
                                          'Warranty Claim',
                                          style: TextStyle(
                                            fontFamily: 'Poppins-Regular',
                                            fontSize: 12,
                                            color: Colors.black,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: ColorResource.lightGrey2, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Padding(
                            padding: EdgeInsets.all(20),
                            child: Column(
                              children: [
                                const Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Invoice',
                                      style: TextStyle(
                                        fontFamily: 'Poppins-Regular',
                                        fontSize: 12,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Icon(Icons.download),
                                  ],
                                ),
                                SizedBox(height: 5),
                                Divider(color: ColorResource.lightGrey2),
                                SizedBox(height: 5),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Invoice ID',
                                          style: TextStyle(
                                            fontFamily: 'Poppins-Regular',
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                            color: ColorResource.lightGrey3,
                                          ),
                                        ),
                                        Text(
                                          InvoiceId == "" ? "N/A" : InvoiceId!,
                                          style: const TextStyle(
                                            fontFamily: 'Inter',
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                            color: ColorResource.lightGrey3,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Invoice Date',
                                          style: TextStyle(
                                            fontFamily: 'Inter',
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                            color: ColorResource.lightGrey3,
                                          ),
                                        ),
                                        Text(
                                          InvoiceData! == "" ? "N/A" : getFormattedDate(InvoiceData!),
                                          style: TextStyle(
                                            fontFamily: 'Inter',
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500,
                                            color: ColorResource.lightGrey3,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Status',
                                          style: TextStyle(
                                            fontFamily: 'Inter',
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                            color: ColorResource.lightGrey3,
                                          ),
                                        ),
                                        Text(
                                          Status! == "" ? "N/A" : Status!,
                                          style: TextStyle(
                                            fontFamily: 'Inter',
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.green,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: ColorResource.lightGrey2, width: 1),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Basic Information',
                                  style: TextStyle(
                                    fontFamily: 'Inter',
                                    fontSize: 12,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                const Divider(color: ColorResource.lightGrey2),
                                const SizedBox(height: 5),
                                info('Model', ModelName == "" ? 'N/A' : ModelName, 'Varient', ModelVarient == "" ? 'N/A' : ModelVarient),
                                const SizedBox(height: 13),
                                info('MFT.Year', MFTyear == "" ? 'N/A' : MFTyear, 'Color Type', ColorType == "" ? 'N/A' : ColorType),
                                const SizedBox(height: 13),
                                info('Subsidy', Subsity == "" ? 'N/A' : Subsity, 'HSN Code', HSNcode == "" ? 'N/A' : HSNcode),
                                const SizedBox(height: 25),
                                const Text(
                                  'Motor Details',
                                  style: TextStyle(
                                    fontFamily: 'Inter',
                                    fontSize: 12,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const Divider(color: ColorResource.lightGrey2),
                                const SizedBox(height: 5),
                                info('Motor No', MotorNo == "" ? 'N/A' : MotorNo, 'Motor', Motor == "" ? 'N/A' : Motor),
                                const SizedBox(height: 13),
                                info('Motor type', MotorType == "" ? 'N/A' : MotorType, 'Motor Range', MotorRange == "" ? 'N/A' : MotorRange),
                                const SizedBox(height: 13),
                                info('Warranty', Warranty == "" ? 'N/A' : Warranty, 'Expiry At', ExpirayAt == "" ? 'N/A' : ExpirayAt),
                                const SizedBox(height: 25),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                      ],
                    ),
                  ),
                ),
              );
            }),
      ),
    );
  }
}
