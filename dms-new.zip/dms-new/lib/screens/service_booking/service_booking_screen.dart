import 'package:dms_dealers/screens/service_booking/service_booking_bloc.dart';
import 'package:dms_dealers/screens/service_booking/service_booking_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../../base/base_state.dart';
import '../../router.dart';
import '../../utils/singleton.dart';
import '../profile/model/profile_details.dart';
import 'model/booking_service.dart';

class ServiceBookingScreen extends StatefulWidget {
  @override
  _ServiceBookingScreenState createState() => _ServiceBookingScreenState();
}

class _ServiceBookingScreenState extends State<ServiceBookingScreen> {
  final _formKey = GlobalKey<FormState>();
  String _noOfServices = '';
  String _serviceType = 'General';
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String _remarks = '';
  late ServiceBookingBloc bloc;
  late ProfileData profileData;
  BuildContext? showpopcontext;

  @override
  void initState() {
    bloc = BlocProvider.of<ServiceBookingBloc>(context);
    bloc.add(ProfileViewApiEvent(context: context));
    super.initState();
  }

  // Function to select date
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  // Function to select time
  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked =
    await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  // Function to handle form submission
  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      // Pass the values to API
      print('No of Services: $_noOfServices');
      print('Service Type: $_serviceType');
      print(
          'Selected Date: ${_selectedDate != null ? DateFormat('yyyy-MM-dd').format(_selectedDate!) : ''}');
      print(
          'Selected Time: ${_selectedTime != null ? _selectedTime!.format(context) : ''}');
      print('Remarks: $_remarks');
      print('Status: Pending');
      print("customerDetails");
      print(FlashSingleton.instance.id);
      print(FlashSingleton.instance.vehicleName);
      print(FlashSingleton.instance.dealerId);

      final Map<String, dynamic> data = {
        "dealer_id":'${FlashSingleton.instance.dealerId}',
        "customer_id": '${FlashSingleton.instance.id}',
        "no_of_service": '${_noOfServices}',
        "vehicle": '${FlashSingleton.instance.vehicleName}',
        "chasis_number": '${FlashSingleton.instance.chasisNo}',
        "service_type": '${_serviceType}',
        "service_time": '${_selectedTime != null ? _selectedTime!.format(context) : ''}',
        "service_date": '${_selectedDate != null ? DateFormat('yyyy-MM-dd').format(_selectedDate!) : ''}',
        "status": "Pending",
        "remarks": '${_remarks}',
      };

      print('No of Services: $data');

      bloc.add(ServiceBookEvent(context: context, arguments: data));
      // Call API or perform any action
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener(
      bloc: bloc,
      listener: (BuildContext context, BaseState state) async {},
      child: BlocBuilder(
        bloc: bloc,
        builder: (BuildContext context, BaseState state) {
          if (state is InitialState) {
            return const Center(
              child: Text('New'),
            );
          } else if (state is SuccessState) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (state.successResponse is ProfileDetails) {
                ProfileDetails response = state.successResponse;
                profileData = response.data;
                FlashSingleton.instance.dealerId = profileData.dealerId;
              }else if (state.successResponse is BookingService) {
                BookingService response = state.successResponse;

                Navigator.pushReplacementNamed(context, AppRoutes.serviceWarranty);

              }
            });
          }
          return Scaffold(
            backgroundColor: Colors.grey[200], // Set the background color to light gray
            appBar: AppBar(
              title: Text('Service Booking'),
              leading: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.pop(context); // Go back to previous page
                },
              ),
            ),
            body: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // No of Services Section
                      Container(
                        padding: EdgeInsets.all(16),
                        margin: EdgeInsets.only(bottom: 20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(color: Colors.grey.shade300, blurRadius: 4)
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Booking information',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            Divider(height: 30,color: Colors.grey),
                            Text(
                              'No. of Services',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 10),
                            TextFormField(
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border when enabled
                                ),
                              ),
                              keyboardType: TextInputType.number,
                              onSaved: (value) {
                                _noOfServices = value!;
                              },
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter the number of services';
                                }
                                return null;
                              },
                            ),
                            SizedBox(height: 20),
                            Text(
                              'Service Type',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 10),
                            DropdownButtonFormField<String>(
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border when enabled
                                ),
                              ),
                              value: _serviceType,
                              items: ['General', 'Custom']
                                  .map((type) => DropdownMenuItem(
                                value: type,
                                child: Text(type),
                              ))
                                  .toList(),
                              onChanged: (value) {
                                setState(() {
                                  _serviceType = value!;
                                });
                              },
                            ),
                            SizedBox(height: 20),
                            Text(
                              'Select Your Date',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 10),
                            TextFormField(
                              readOnly: true,
                              decoration: InputDecoration(
                                suffixIcon: IconButton(
                                  icon: Icon(Icons.calendar_today),
                                  onPressed: () => _selectDate(context),
                                ),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border when enabled
                                ),
                              ),
                              controller: TextEditingController(
                                text: _selectedDate != null
                                    ? DateFormat('yyyy-MM-dd').format(_selectedDate!)
                                    : '',
                              ),
                            ),
                            SizedBox(height: 20),
                            Text(
                              'Select Your Time',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 10),
                            TextFormField(
                              readOnly: true,
                              decoration: InputDecoration(
                                suffixIcon: IconButton(
                                  icon: Icon(Icons.access_time),
                                  onPressed: () => _selectTime(context),
                                ),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border when enabled
                                ),
                              ),
                              controller: TextEditingController(
                                text: _selectedTime != null
                                    ? _selectedTime!.format(context)
                                    : '',
                              ),
                            ),
                            SizedBox(height: 20),
                            Text(
                              'Remarks',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 10),
                            TextFormField(
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey), // Gray border when enabled
                                ),
                              ),
                              maxLines: 3,
                              onSaved: (value) {
                                _remarks = value!;
                              },
                            ),
                          ],
                        ),
                      ),

                      // Buttons
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          OutlinedButton(
                            onPressed: () {
                              Navigator.pop(context); // Go back to previous page
                            },
                            child: Text('Cancel'),
                          ),
                          SizedBox(width:10),  // If want horizontal space use width  for vertical use height
                          ElevatedButton(
                            onPressed: _submitForm,
                            child: Text('Book'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  showLoader() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        showpopcontext = context;
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );
  }
}
