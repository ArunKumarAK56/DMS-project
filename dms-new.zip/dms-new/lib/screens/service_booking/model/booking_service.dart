// To parse this JSON data, do
//
//     final bookingService = bookingServiceFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

BookingService bookingServiceFromJson(String str) => BookingService.fromJson(json.decode(str));

String bookingServiceToJson(BookingService data) => json.encode(data.toJson());

class BookingService {
  Data data;
  String status;

  BookingService({
    required this.data,
    required this.status,
  });

  factory BookingService.fromJson(Map<String, dynamic> json) => BookingService(
    data: Data.fromJson(json["data"]),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": data.toJson(),
    "status": status,
  };
}

class Data {
  String dealerId;
  String customerId;
  String vehicle;
  String chasisNumber;
  String noOfService;
  String serviceType;
  DateTime serviceDate;
  String serviceTime;
  String remarks;
  String status;
  String reason;
  DateTime updatedAt;
  DateTime createdAt;
  int id;

  Data({
    required this.dealerId,
    required this.customerId,
    required this.vehicle,
    required this.chasisNumber,
    required this.noOfService,
    required this.serviceType,
    required this.serviceDate,
    required this.serviceTime,
    required this.remarks,
    required this.status,
    required this.reason,
    required this.updatedAt,
    required this.createdAt,
    required this.id,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    dealerId: json["dealer_id"] ?? '',
    customerId: json["customer_id"] ?? '',
    vehicle: json["vehicle"] ?? '',
    chasisNumber: json["chasis_number"] ?? '',
    noOfService: json["no_of_service"] ?? '',
    serviceType: json["service_type"] ?? '',
    serviceDate: json["service_date"] != null ? DateTime.parse(json["service_date"]) : DateTime.now(),
    serviceTime: json["service_time"] ?? '',
    remarks: json["remarks"] ?? '',
    status: json["status"] ?? '',
    reason: json["reason"] ?? '',
    updatedAt: json["updated_at"] != null ? DateTime.parse(json["updated_at"]) : DateTime.now(),
    createdAt: json["created_at"] != null ? DateTime.parse(json["created_at"]) : DateTime.now(),
    id: json["id"] ?? 0,
  );

  Map<String, dynamic> toJson() => {
    "dealer_id": dealerId,
    "customer_id": customerId,
    "vehicle": vehicle,
    "chasis_number": chasisNumber,
    "no_of_service": noOfService,
    "service_type": serviceType,
    "service_date": "${serviceDate.year.toString().padLeft(4, '0')}-${serviceDate.month.toString().padLeft(2, '0')}-${serviceDate.day.toString().padLeft(2, '0')}",
    "service_time": serviceTime,
    "remarks": remarks,
    "status": status,
    "reason": reason,
    "updated_at": updatedAt.toIso8601String(),
    "created_at": createdAt.toIso8601String(),
    "id": id,
  };
}