
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class ServiceBookingEvent extends BaseEquatable {}

class ServiceBookingEventInitialEvent extends ServiceBookingEvent {
  BuildContext? context;
  dynamic arguments;

  ServiceBookingEventInitialEvent({this.context});

}

class ServiceSubmitEvent extends ServiceBookingEvent {
  BuildContext? context;
  dynamic arguments;

  ServiceSubmitEvent({this.context,this.arguments});

}

class ServiceBookEvent extends ServiceBookingEvent {
  BuildContext? context;
  dynamic arguments;
  ServiceBookEvent({this.context,this.arguments});
}


class ProfileViewApiEvent extends ServiceBookingEvent {
  ProfileViewApiEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}