
import 'dart:convert';

import 'package:flutter_bloc/flutter_bloc.dart';

import '../../base/base_state.dart';
import '../profile/model/profile_details.dart';
import 'model/booking_service.dart';
import 'service_booking_event.dart';
import '../../base/base_state.dart';
import '../../http/api_repository.dart';
import '../../http/httpurls.dart';
import '../../utils/contants.dart';
import '../../utils/singleton.dart';

class ServiceBookingBloc extends Bloc<ServiceBookingEvent, BaseState> {
  ServiceBookingBloc() : super(InitialState());


  @override
  Stream<BaseState> mapEventToState(
      ServiceBookingEvent event,
      ) async* {
    if (event is ServiceSubmitEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }else if (event is ProfileViewApiEvent) {
      dynamic response;
      yield LoadingState();
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getProfileDetails}${FlashSingleton.instance.id}",
          userArguments: jsonEncode(event.arguments),
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      response = ProfileDetails.fromJson(returnableValues);

      yield SuccessState(successResponse: response);
    }else if (event is ServiceBookEvent) {
      dynamic response;
      yield LoadingState();
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          HttpUrl.ServiceBooking,
          userArguments: jsonEncode(event.arguments),
          method: ApiRequestMethod.post,
          isBearerTokenNeed: true,
          context: event.context);

      response = BookingService.fromJson(returnableValues);

      print("responseresponse");

      print(response);

      yield SuccessState(successResponse: response);
    }
  }
}