
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class NotificationEvent extends BaseEquatable {}

class NotificationEventInitialEvent extends NotificationEvent {
  BuildContext? context;
  dynamic arguments;

  NotificationEventInitialEvent({this.context});

}
