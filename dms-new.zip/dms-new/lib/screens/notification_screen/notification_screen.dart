import 'package:dms_dealers/screens/spare_details_page/spare_details_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../base/base_state.dart';
import '../../utils/sparelist.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({Key? key}) : super(key: key);

  @override
  _NotificationScreenState createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  late SpareDetailsBloc bloc;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener(
        bloc: bloc,
        listener: (BuildContext context, BaseState state) async {},
        child: BlocBuilder(
            bloc: bloc,
            builder: (BuildContext context, BaseState state) {
              if (state is InitialState) {
                return const Center(
                  child: Text('New'),
                );
              } else if (state is SuccessState) {

              }
              return SafeArea(
                  child: Scaffold(
                    backgroundColor: Colors.white70,
                    appBar: AppBar(
                      leading:Extra().iconViewer(Icons.arrow_back_ios) ,
                      title: Extra().headlineText('Spare Details'),
                    ),
                    body: Column(
                      children: [
                        Extra().containerView(
                            height: 85,
                            child: Extra().listTileView()
                        ),
                        Extra().containerView(
                          height: 230,
                          child: Extra().bannerView(),

                        ),
                        Extra().containerView(
                            height: 280,
                            child: pdfViewer().pdfBannerViewer()

                        )
                      ],
                    ),
                  ));
            }));
  }
}