import 'package:flutter_bloc/flutter_bloc.dart';
import '../../base/base_state.dart';
import 'notification_event.dart';


class NotificationBloc extends Bloc<NotificationEvent, BaseState> {
  NotificationBloc() : super(InitialState());


  @override
  Stream<BaseState> mapEventToState(
      NotificationEvent event,
      ) async* {
    if (event is NotificationEventInitialEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }
  }
}