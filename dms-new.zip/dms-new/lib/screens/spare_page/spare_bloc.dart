import 'dart:convert';

import 'package:dms_dealers/http/api_repository.dart';
import 'package:dms_dealers/http/httpurls.dart';
import 'package:dms_dealers/screens/about_vehicle/model/get_vehicle.dart';
import 'package:dms_dealers/screens/spare_page/model/get_spare.dart';
import 'package:dms_dealers/screens/spare_page/spare_event.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../base/base_state.dart';
import '../../utils/contants.dart';
import 'model/get_accessory.dart';


class SpareBloc extends Bloc<SpareEvent, BaseState> {
  SpareBloc() : super(InitialState());


  @override
  Stream<BaseState> mapEventToState(
      SpareEvent event,
      ) async* {
    if (event is SpareEventInitialEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }else if (event is AccessoryDetailsEvent) {
      dynamic response;
      yield LoadingState();
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getAccessoryDetails}${event.arguments['product_name']}/${event.arguments['user_id']}",
          userArguments: jsonEncode(event.arguments),
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);
      response = GetAccessoryDetail.fromJson(returnableValues);
      yield SuccessState(successResponse: response);
    }else if (event is SpareDetailsEvent) {
      dynamic response;
      yield LoadingState();
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getSpareDetails}${event.arguments['product_name']}/${event.arguments['user_id']}",
          userArguments: jsonEncode(event.arguments),
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);
      response = GetSpareDetail.fromJson(returnableValues);
      yield SuccessState(successResponse: response);
    }else if (event is GetVehicleSpareEvent) {
      dynamic response;
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getVehicle}${event.arguments}",
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      debugPrint('state response $returnableValues');

      if (returnableValues is String) {
        response = returnableValues;
      } else {
        debugPrint('state response $returnableValues');
        response = GetVechicle.fromJson(returnableValues);
      }
      yield SuccessState(successResponse: response);
    }
  }
}