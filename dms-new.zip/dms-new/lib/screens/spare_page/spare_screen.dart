import 'package:dms_dealers/router.dart';
import 'package:dms_dealers/screens/service_waranty.dart/service_warranty_event.dart';
import 'package:dms_dealers/screens/spare_page/model/get_spare.dart';
import 'package:dms_dealers/screens/spare_page/spare_bloc.dart';
import 'package:dms_dealers/screens/spare_page/spare_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../base/base_state.dart';
import '../../utils/color_resources.dart';
import '../../utils/contants.dart';
import '../../utils/singleton.dart';
import '../../utils/sparelist.dart';
import '../about_vehicle/model/get_vehicle.dart';
import '../drawer/drawer.dart';
import '../drawer/drawer_bloc.dart';
import '../drawer/drawer_event.dart';
import 'model/get_accessory.dart';

class SpareScreen extends StatefulWidget {
  const SpareScreen({Key? key}) : super(key: key);

  @override
  _SpareScreenState createState() => _SpareScreenState();
}

class _SpareScreenState extends State<SpareScreen>
    with SingleTickerProviderStateMixin {
  late TabController tabController;
  late SpareBloc bloc;
  List<Vechicle> _items = [];
  List<SpareList> _spareList = [];
  List<AccessoryList> _accessoryList = [];
  bool _isLoading = true;
  Vechicle? _selectedItem;

  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of<SpareBloc>(context);
    bloc.add(GetVehicleSpareEvent(context: context, arguments: FlashSingleton.instance.id));
    tabController = TabController(length: 2, vsync: this);
    tabController.addListener(() {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<SpareBloc, BaseState>(
      bloc: bloc,
      listener: (BuildContext context, BaseState state) async {},
      child: BlocBuilder<SpareBloc, BaseState>(
        bloc: bloc,
        builder: (BuildContext context, BaseState state) {
          if (state is InitialState) {
            return const Center(
              child: Text('Loading...'),
            );
          } else if (state is SuccessState) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (state.successResponse is GetVechicle) {
                final GetVechicle response = state.successResponse;
                if (response.status == Constants.success) {
                  setState(() {
                    _items = response.data;
                    if (_items.isNotEmpty) {
                      _selectedItem = _items[0];  // Set initial value to the first item
                      _fetchAdditionalData(_selectedItem!);
                    }
                    _isLoading = false;
                  });
                }
              } else if (state.successResponse is GetSpareDetail) {
                final GetSpareDetail response = state.successResponse;
                if (response.status == Constants.success) {
                  setState(() {
                    _spareList = response.data;
                    _isLoading = false;
                  });
                }
              } else if (state.successResponse is GetAccessoryDetail) {
                final GetAccessoryDetail response = state.successResponse;
                if (response.status == Constants.success) {
                  setState(() {
                    _accessoryList = response.data;
                    _isLoading = false;
                  });
                }
              }
            });
          }

          return SafeArea(
            child: Scaffold(
              appBar: AppBar(
                automaticallyImplyLeading: false,
                title: const Text(
                  'Service / Warranty',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                actions: [
                  const Padding(
                    padding: EdgeInsets.only(right: 10.0),
                    child: Icon(Icons.notification_add),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 10.0),
                    child: Builder(
                      builder: (context) => InkWell(
                        onTap: () {
                          Scaffold.of(context).openDrawer();
                        },
                        child: const Icon(Icons.menu),
                      ),
                    ),
                  ),
                ],
              ),
              drawer: Drawer(
                width: MediaQuery.of(context).size.width * 0.85,
                child: BlocProvider(
                  create: (BuildContext context) =>
                  DrawerBloc()..add(DrawerInitialEvent(context: context)),
                  child: DmsDrawer(),
                ),
              ),
              body: DefaultTabController(
                length: 2,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Container(
                        alignment: Alignment.topLeft,
                        child: _isLoading
                            ? const CircularProgressIndicator()
                            : DropdownButton<Vechicle>(
                          hint: const Text('Select Vehicle'),
                          value: _selectedItem,
                          onChanged: (Vechicle? newValue) {
                            if (newValue != null) {
                              setState(() {
                                _selectedItem = newValue;
                                _fetchAdditionalData(newValue);
                              });
                            }
                          },
                          items: _items.map((Vechicle vechicle) {
                            return DropdownMenuItem<Vechicle>(
                              value: vechicle,
                              child: Text(vechicle.productName),
                            );
                          }).toList(),
                        ),
                      ),
                      // Container(
                      //   height: 40,
                      //   decoration: BoxDecoration(
                      //     color: Colors.grey[300],
                      //     borderRadius: BorderRadius.circular(25.0),
                      //   ),
                      //   child: TabBar(
                      //     controller: tabController,
                      //     indicator: BoxDecoration(
                      //       borderRadius: BorderRadius.circular(25.0),
                      //       color: Colors.green,
                      //     ),
                      //     labelColor: Colors.white,
                      //     unselectedLabelColor: Colors.black,
                      //     tabs: const [
                      //       Tab(text: 'Spare Parts'),
                      //       Tab(text: 'Accessories'),
                      //     ],
                      //   ),
                      // ),
                      // Expanded(
                      //   child: TabBarView(
                      //     controller: tabController,
                      //     children: [
                      //       ListView.separated(
                      //         itemCount: _spareList.length,
                      //         separatorBuilder: (BuildContext context, int index) {
                      //           return const Divider();
                      //         },
                      //         itemBuilder: (BuildContext context, int index) {
                      //           SpareList spareList = _spareList[index];
                      //           return InkWell(
                      //             onTap: () {
                      //               Navigator.pushNamed(
                      //                 context,
                      //                 AppRoutes.spareDetailsScreen,
                      //                 arguments: spareList,
                      //               );
                      //             },
                      //             child: ListTile(
                      //               title: Text(spareList.spareName),
                      //               subtitle: Text('${spareList.date}'),
                      //               trailing: Text("\u{20B9} ${spareList.price}"),
                      //             ),
                      //           );
                      //         },
                      //       ),
                      //       ListView.separated(
                      //         itemCount: _accessoryList.length,
                      //         separatorBuilder: (BuildContext context, int index) {
                      //           return const Divider();
                      //         },
                      //         itemBuilder: (BuildContext context, int index) {
                      //           AccessoryList accessoryList = _accessoryList[index];
                      //           return InkWell(
                      //             onTap: () {
                      //               Navigator.pushNamed(
                      //                 context,
                      //                 AppRoutes.spareDetailsScreen,
                      //                 arguments: accessoryList,
                      //               );
                      //             },
                      //             child: ListTile(
                      //               title: Text(accessoryList.accessoryName),
                      //               subtitle: Text('${accessoryList.date}'),
                      //               trailing: Text("\u{20B9} ${accessoryList.price}"),
                      //             ),
                      //           );
                      //         },
                      //       ),
                      //     ],
                      //   ),
                      // ),
                      Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(
                            25.0,
                          ),
                        ),
                        child:  TabBar(
                          tabs: const [
                            Tab(text: 'Spare'),
                            Tab(
                              text: 'Accessories',
                            ),
                          ],
                          labelStyle: const TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 10,
                              fontFamily: 'Inter'),
                          indicator: BoxDecoration(
                            color: ColorResource.primaryColor,
                            borderRadius: BorderRadius.circular(15.0),
                          ),

                          labelColor: Colors.white,
                          unselectedLabelColor: Colors.black,
                          indicatorSize: TabBarIndicatorSize.tab,
                        ),
                      ),
                      // tab bar view here
                      Expanded(
                        child: TabBarView(
                          controller: tabController,
                          children: [
                            // first tab bar view widget
                            _spareList.length != 0 ?

                            ListView.separated(
                                itemCount: _spareList.length,
                                separatorBuilder:
                                    (BuildContext context,
                                    int index) {
                                  return Extra().divide();
                                },
                                itemBuilder: (
                                    BuildContext context,
                                    int index) {
                                  SpareList spareList = _spareList[index];
                                  return InkWell(
                                      onTap: () {
                                        Navigator.pushNamed(context, AppRoutes.spareDetailsScreen,arguments: spareList);
                                      },
                                      child: ListTile(
                                        title: Extra().titleViewer("${spareList.spareName}"),
                                        subtitle: Extra().subViewer('${spareList.date}'),
                                        trailing: Extra().moneyViewer("\u{20B9} ${spareList.price}"),
                                      ));
                                })
                            : const Center(
                              child: Text('No data found')
                            ),

                            _accessoryList.length != 0 ?

                            // second tab bar view widget
                            ListView.separated(
                                itemCount: _accessoryList.length,
                                separatorBuilder:
                                    (BuildContext context,
                                    int index) {
                                  return Extra().divide();
                                },
                                itemBuilder: (
                                    BuildContext context,
                                    int index) {
                                  AccessoryList accessoryList = _accessoryList[index];
                                  return InkWell(
                                      onTap: () {
                                        Navigator.pushNamed(context, AppRoutes.spareDetailsScreen,arguments: accessoryList);
                                        //  NavigationRoute().navigation(context);
                                      },
                                      child: ListTile(
                                        title: Extra().titleViewer("${accessoryList.accessoryName}"),
                                        subtitle: Extra().subViewer('${accessoryList.date}'),
                                        trailing: Extra().moneyViewer("\u{20B9} ${accessoryList.price}"),
                                      ));
                                })
                                : const Center(
                              child:Text('No data found')
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _fetchAdditionalData(Vechicle vehicle) {
    bloc.add(SpareDetailsEvent(context: context, arguments: {
      'product_name': vehicle.productName,
      'user_id': FlashSingleton.instance.id,
    }));
    bloc.add(AccessoryDetailsEvent(context: context, arguments: {
      'product_name': vehicle.productName,
      'user_id': FlashSingleton.instance.id,
    }));
  }
}
