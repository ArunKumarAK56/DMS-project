// To parse this JSON data, do
//
//     final getAccessoryDetail = getAccessoryDetailFromJson(jsonString);

import 'dart:convert';

GetAccessoryDetail getAccessoryDetailFromJson(String str) => GetAccessoryDetail.fromJson(json.decode(str));

String getAccessoryDetailToJson(GetAccessoryDetail data) => json.encode(data.toJson());

class GetAccessoryDetail {
  List<AccessoryList> data;
  String status;

  GetAccessoryDetail({
    required this.data,
    required this.status,
  });

  factory GetAccessoryDetail.fromJson(Map<String, dynamic> json) => GetAccessoryDetail(
    data: List<AccessoryList>.from(json["data"].map((x) => AccessoryList.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "status": status,
  };
}

class AccessoryList {
  String accessoryName;
  String price;
  DateTime date;
  AccessoryDetails accessoryDetails;
  StockDetails stockDetails;
  InvoiceDetails invoiceDetails;

  AccessoryList({
    required this.accessoryName,
    required this.price,
    required this.date,
    required this.accessoryDetails,
    required this.stockDetails,
    required this.invoiceDetails,
  });

  factory AccessoryList.fromJson(Map<String, dynamic> json) => AccessoryList(
    accessoryName: json["accessory_name"],
    price: json["price"],
    date: DateTime.parse(json["date"]),
    accessoryDetails: AccessoryDetails.fromJson(json["accessory_details"]),
    stockDetails: StockDetails.fromJson(json["stock_details"]),
    invoiceDetails: InvoiceDetails.fromJson(json["invoice_details"]),
  );

  Map<String, dynamic> toJson() => {
    "accessory_name": accessoryName,
    "price": price,
    "date": date.toIso8601String(),
    "accessory_details": accessoryDetails.toJson(),
    "stock_details": stockDetails.toJson(),
    "invoice_details": invoiceDetails.toJson(),
  };
}

class AccessoryDetails {
  int id;
  String productType;
  int vehicleId;
  int variantId;
  String productName;
  String oemId;
  String productImg;
  int cgst;
  int sgst;
  int igst;
  String company;
  int hsnNo;
  String price;
  dynamic otherDetails;
  DateTime createdAt;
  DateTime updatedAt;

  AccessoryDetails({
    required this.id,
    required this.productType,
    required this.vehicleId,
    required this.variantId,
    required this.productName,
    required this.oemId,
    required this.productImg,
    required this.cgst,
    required this.sgst,
    required this.igst,
    required this.company,
    required this.hsnNo,
    required this.price,
    required this.otherDetails,
    required this.createdAt,
    required this.updatedAt,
  });

  factory AccessoryDetails.fromJson(Map<String, dynamic> json) => AccessoryDetails(
    id: json["id"],
    productType: json["product_type"],
    vehicleId: json["vehicle_id"],
    variantId: json["variant_id"],
    productName: json["product_name"],
    oemId: json["oem_id"],
    productImg: json["product_img"],
    cgst: json["cgst"],
    sgst: json["sgst"],
    igst: json["igst"],
    company: json["company"],
    hsnNo: json["hsn_no"],
    price: json["price"],
    otherDetails: json["other_details"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_type": productType,
    "vehicle_id": vehicleId,
    "variant_id": variantId,
    "product_name": productName,
    "oem_id": oemId,
    "product_img": productImg,
    "cgst": cgst,
    "sgst": sgst,
    "igst": igst,
    "company": company,
    "hsn_no": hsnNo,
    "price": price,
    "other_details": otherDetails,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class InvoiceDetails {
  int id;
  String dealerId;
  String invoiceId;
  int customerId;
  String customerName;
  DateTime invoiceDate;
  DateTime dueDate;
  String termsConditions;
  String fileUrl;
  int subTotal;
  int sgst;
  int cgst;
  int igst;
  int discount;
  String status;
  int total;
  String pendingPayments;
  String invoiceType;
  DateTime createdAt;
  DateTime updatedAt;

  InvoiceDetails({
    required this.id,
    required this.dealerId,
    required this.invoiceId,
    required this.customerId,
    required this.customerName,
    required this.invoiceDate,
    required this.dueDate,
    required this.termsConditions,
    required this.fileUrl,
    required this.subTotal,
    required this.sgst,
    required this.cgst,
    required this.igst,
    required this.discount,
    required this.status,
    required this.total,
    required this.pendingPayments,
    required this.invoiceType,
    required this.createdAt,
    required this.updatedAt,
  });

  factory InvoiceDetails.fromJson(Map<String, dynamic> json) => InvoiceDetails(
    id: json["id"],
    dealerId: json["dealer_id"],
    invoiceId: json["invoice_id"],
    customerId: json["customer_id"],
    customerName: json["customer_name"],
    invoiceDate: DateTime.parse(json["invoice_date"]),
    dueDate: DateTime.parse(json["due_date"]),
    termsConditions: json["terms_conditions"],
    fileUrl: json["file_url"],
    subTotal: json["sub_total"],
    sgst: json["sgst"],
    cgst: json["cgst"],
    igst: json["igst"],
    discount: json["discount"],
    status: json["status"],
    total: json["total"],
    pendingPayments: json["pending_payments"],
    invoiceType: json["invoice_type"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "dealer_id": dealerId,
    "invoice_id": invoiceId,
    "customer_id": customerId,
    "customer_name": customerName,
    "invoice_date": "${invoiceDate.year.toString().padLeft(4, '0')}-${invoiceDate.month.toString().padLeft(2, '0')}-${invoiceDate.day.toString().padLeft(2, '0')}",
    "due_date": "${dueDate.year.toString().padLeft(4, '0')}-${dueDate.month.toString().padLeft(2, '0')}-${dueDate.day.toString().padLeft(2, '0')}",
    "terms_conditions": termsConditions,
    "file_url": fileUrl,
    "sub_total": subTotal,
    "sgst": sgst,
    "cgst": cgst,
    "igst": igst,
    "discount": discount,
    "status": status,
    "total": total,
    "pending_payments": pendingPayments,
    "invoice_type": invoiceType,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class StockDetails {
  int id;
  int accessoryStocksId;
  String product;
  String company;
  String partCode;
  DateTime createdAt;
  DateTime updatedAt;

  StockDetails({
    required this.id,
    required this.accessoryStocksId,
    required this.product,
    required this.company,
    required this.partCode,
    required this.createdAt,
    required this.updatedAt,
  });

  factory StockDetails.fromJson(Map<String, dynamic> json) => StockDetails(
    id: json["id"],
    accessoryStocksId: json["accessory_stocks_id"],
    product: json["product"],
    company: json["company"],
    partCode: json["part_code"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "accessory_stocks_id": accessoryStocksId,
    "product": product,
    "company": company,
    "part_code": partCode,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}
