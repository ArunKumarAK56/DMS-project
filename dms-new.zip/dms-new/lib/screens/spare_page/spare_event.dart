
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class SpareEvent extends BaseEquatable {}

class SpareEventInitialEvent extends SpareEvent {
  BuildContext? context;
  dynamic arguments;

  SpareEventInitialEvent({this.context});

}

class GetVehicleSpareEvent extends SpareEvent {
  GetVehicleSpareEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}

class SpareDetailsEvent extends SpareEvent {
  SpareDetailsEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}

class AccessoryDetailsEvent extends SpareEvent {
  AccessoryDetailsEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}


