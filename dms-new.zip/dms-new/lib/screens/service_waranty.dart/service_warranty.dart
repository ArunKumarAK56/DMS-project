import 'package:dms_dealers/base/base_state.dart';
import 'package:dms_dealers/router.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_service_by_customer.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_services.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_warranty.dart';
import 'package:dms_dealers/screens/service_waranty.dart/service.dart';
import 'package:dms_dealers/screens/service_waranty.dart/service_warranty_bloc.dart';
import 'package:dms_dealers/screens/service_waranty.dart/service_warranty_event.dart';
import 'package:dms_dealers/screens/service_waranty.dart/warranty.dart';
import 'package:dms_dealers/utils/color_resources.dart';
import 'package:dms_dealers/utils/image_resources.dart';
import 'package:dms_dealers/utils/singleton.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../utils/contants.dart';
import '../about_vehicle/model/get_vehicle.dart';
import '../drawer/drawer.dart';
import '../drawer/drawer_bloc.dart';
import '../drawer/drawer_event.dart';

class ServiceWarranty extends StatefulWidget {
  const ServiceWarranty({super.key});

  @override
  State<ServiceWarranty> createState() => _ServiceWarrantyState();
}

class _ServiceWarrantyState extends State<ServiceWarranty> {
  late ServiceWarrantyBloc bloc;
  List<Vechicle> _items = [];
  List<Datum> serivesList = [];
  List<ServiceData> getserivesList = [];
  List<WarrantyList> warrantyList = [];
  Vechicle? _selectedItem;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    bloc = BlocProvider.of<ServiceWarrantyBloc>(context);
    bloc.add(GetVehicleEvent(context: context, arguments: FlashSingleton.instance.id));
    print("phone${FlashSingleton.instance.phone}");
    print("phoneotp${FlashSingleton.instance.otp}");
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<ServiceWarrantyBloc, BaseState>(
      bloc: bloc,
      listener: (BuildContext context, BaseState state) async {},
      child: BlocBuilder<ServiceWarrantyBloc, BaseState>(
        bloc: bloc,
        builder: (BuildContext context, BaseState state) {
          if (state is InitialState) {
            return const Center(
              child: Text('Loading...'),
            );
          } else if (state is SuccessState) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (state.successResponse is GetVechicle) {
                final GetVechicle response = state.successResponse;
                if (response.status == Constants.success) {
                  setState(() {
                    _items = response.data;
                    if (_items.isNotEmpty) {
                      _selectedItem = _items[0];
                      _fetchAdditionalData(_selectedItem!);
                    }
                    _isLoading = false;
                  });
                }
              } else if (state.successResponse is GetServices) {
                final GetServices response = state.successResponse;
                if (response.status == Constants.success) {
                  setState(() {
                    serivesList = response.data;
                    _isLoading = false;
                  });
                }
              } else if (state.successResponse is GetWarranty) {
                final GetWarranty response = state.successResponse;
                if (response.status == Constants.success) {
                  setState(() {
                    warrantyList = response.data;
                    _isLoading = false;
                  });
                }
              }else if (state.successResponse is GetBookService) {
                final GetBookService response = state.successResponse;
                if (response.status == Constants.success) {
                  setState(() {
                    getserivesList = response.data;
                    _isLoading = false;
                  });
                }
              }
            });
          }

          return Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              title: const Text(
                'Service / Warranty',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              actions: [
                const Padding(
                  padding: EdgeInsets.only(right: 10.0),
                  child: Icon(Icons.notification_add),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 10.0),
                  child: Builder(
                    builder: (context) => InkWell(
                      onTap: () {
                        Scaffold.of(context).openDrawer();
                      },
                      child: const Icon(Icons.menu),
                    ),
                  ),
                ),
              ],
            ),
            drawer: Drawer(
              width: MediaQuery.of(context).size.width * 0.85,
              child: BlocProvider(
                create: (BuildContext context) =>
                DrawerBloc()..add(DrawerInitialEvent(context: context)),
                child: DmsDrawer(),
              ),
            ),
            body: DefaultTabController(
              length: 2,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      alignment: Alignment.topLeft,
                      child: _isLoading
                          ? const CircularProgressIndicator()
                          : DropdownButton<Vechicle>(
                        hint: const Text('Select Vehicle'),
                        value: _selectedItem,
                        onChanged: (Vechicle? newValue) {
                          if (newValue != null) {
                            setState(() {
                              _selectedItem = newValue;
                              _fetchAdditionalData(newValue);
                            });
                          }
                        },
                        items: _items.map((Vechicle vechicle) {
                          return DropdownMenuItem<Vechicle>(
                            value: vechicle,
                            child: Text(vechicle.productName),
                          );
                        }).toList(),
                      ),
                    ),
                    TabBar(
                      tabs: const [
                        Tab(text: 'Service'),
                        Tab(text: 'Warranty'),
                      ],
                      labelStyle: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 10,
                        fontFamily: 'Inter',
                      ),
                      indicator: BoxDecoration(
                        color: ColorResource.primaryColor,
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      labelColor: Colors.white,
                      unselectedLabelColor: Colors.black,
                      indicatorSize: TabBarIndicatorSize.tab,
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          Service(servicesList: serivesList,getserivesList : getserivesList),
                          Warranty(warrantyList: warrantyList),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            floatingActionButton: FloatingActionButton.extended(
              onPressed: () {
                Navigator.pushReplacementNamed(context, AppRoutes.service_booking);
              },
              label: const Text(
                'Book Service',
                style: TextStyle(
                  fontFamily: "Inter",
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
              icon: const ImageIcon(
                AssetImage(ImageResource.book),
                color: Colors.white,
              ),
              backgroundColor: ColorResource.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25.0),
              ),
            ),
          );
        },
      ),
    );
  }

  void _fetchAdditionalData(Vechicle vehicle) {

    FlashSingleton.instance.vehicleName = vehicle.productName;
    FlashSingleton.instance.chasisNo = vehicle.chasisNo;

    bloc.add(GetServicesEvent(context: context, arguments: {
      'chasis_no': vehicle.chasisNo,
    }));

    bloc.add(GetBookServiceCustomerEvent(context: context, arguments: {
      'chasis_no': vehicle.chasisNo,
    }));
    bloc.add(GetWarrantyEvent(context: context, arguments: {
      'chasis_no': vehicle.chasisNo,
    }));
  }
}
