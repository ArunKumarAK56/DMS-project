import 'package:dms_dealers/screens/service_waranty.dart/model/get_service_by_customer.dart';
import 'package:flutter/material.dart';

class BookedServiceCard extends StatelessWidget {
  final List<ServiceData> getserivesList;

  // You can pass the index or specific data in a list
  const BookedServiceCard({super.key, required this.getserivesList});

  @override
  Widget build(BuildContext context) {
    print("getserivesList.length: ${getserivesList.length}");

    // Check if the list is not empty to avoid any error
    if (getserivesList.isEmpty) {
      return const Center(child: Text('No booked services available.'));
    }

    // You can use a ListView or iterate through the list if needed
    // Here we show the first service for simplicity.
    final service = getserivesList[0];

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Booked Service',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  // Bind service date and time dynamically
                  Text(
                    '${service.serviceDate}, ${service.serviceTime ?? ''}',
                    style: const TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 10,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                ],
              ),
              InkWell(
                onTap: () {
                  // Action when Edit is tapped
                },
                child: const Row(
                  children: [
                    Icon(
                      Icons.edit,
                      color: Colors.blue,
                      size: 20,
                    ),
                    SizedBox(width: 4),
                    Text(
                      'Edit',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 14,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                ),
              )
            ]),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'No. of Service',
                      style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 12,
                          fontWeight: FontWeight.w400),
                    ),
                    const SizedBox(height: 4),
                    // Bind noOfService dynamically
                    Text(
                      service.noOfService ?? 'N/A',
                      style: const TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Service Type',
                      style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 12,
                          fontWeight: FontWeight.w400),
                    ),
                    const SizedBox(height: 4),
                    // Bind serviceType dynamically
                    Text(
                      service.serviceType ?? 'N/A',
                      style: const TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Status',
                      style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 12,
                          fontWeight: FontWeight.w400),
                    ),
                    const SizedBox(height: 4),
                    // Bind status dynamically
                    Text(
                      service.status ?? 'N/A',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: service.status == 'Pending'
                            ? Colors.orange
                            : Colors.green, // Color based on status
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Divider(color: Colors.grey),
            const SizedBox(height: 10),
            const Text(
              'Remarks',
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 12,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 4),
            // Bind remarks dynamically
            Text(
              service.remarks ?? 'No remarks available.',
              style: const TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w400,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
