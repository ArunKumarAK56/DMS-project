
import 'package:dms_dealers/http/api_repository.dart';
import 'package:dms_dealers/http/httpurls.dart';
import 'package:dms_dealers/screens/about_vehicle/model/get_vehicle.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_services.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_warranty.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_service_by_customer.dart';
import 'package:dms_dealers/utils/contants.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../base/base_state.dart';
import 'service_warranty_event.dart';

import '../../utils/singleton.dart';


class ServiceWarrantyBloc extends Bloc<ServiceWarrantyEvent, BaseState> {
  ServiceWarrantyBloc() : super(InitialState());


  @override
  Stream<BaseState> mapEventToState(
      ServiceWarrantyEvent event,
      ) async* {
    if (event is ServiceWarrantyInitialEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }else if (event is GetVehicleEvent) {
      dynamic response;
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getVehicle}${event.arguments}",
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      debugPrint('state response $returnableValues');

      if (returnableValues is String) {
        response = returnableValues;
      } else {
        debugPrint('state response $returnableValues');
        response = GetVechicle.fromJson(returnableValues);
      }
      yield SuccessState(successResponse: response);
    }else if (event is GetServicesEvent) {
      dynamic response;
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getService}${event.arguments['chasis_no']}",
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      debugPrint('state response $returnableValues');

      if (returnableValues is String) {
        response = returnableValues;
      } else {
        debugPrint('state response $returnableValues');
        response = GetServices.fromJson(returnableValues);
      }
      yield SuccessState(successResponse: response);
    }else if (event is GetWarrantyEvent) {
      dynamic response;
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getWarranty}${event.arguments['chasis_no']}",
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      debugPrint('state response $returnableValues');

      if (returnableValues is String) {
        response = returnableValues;
      } else {
        debugPrint('state response $returnableValues');
        response = GetWarranty.fromJson(returnableValues);
      }
      yield SuccessState(successResponse: response);
    }else if (event is GetBookServiceCustomerEvent) {
      dynamic response;
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getBookServiceCustomer}${FlashSingleton.instance.id}",
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      debugPrint('state response $returnableValues');

      if (returnableValues is String) {
        response = returnableValues;
        print(""+response);
      } else {
        // Convert the response to GetBookService
        response = GetBookService.fromJson(returnableValues);

        // Filter the data to include only entries with status "Pending"
        List<ServiceData> pendingServices = response.data
            .where((service) => service.status == "Pending")
            .toList();

        // Print or debug filtered data
        debugPrint('Filtered Pending Services: ${pendingServices.map((e) => e.toJson()).toList()}');

        // Replace response with filtered result if needed
        response = GetBookService(data: pendingServices, status: response.status);
      }
      yield SuccessState(successResponse: response);
    }
  }
}