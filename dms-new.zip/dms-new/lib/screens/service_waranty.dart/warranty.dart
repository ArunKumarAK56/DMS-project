import 'package:dms_dealers/screens/service_waranty.dart/model/get_warranty.dart';
import 'package:dms_dealers/screens/service_waranty.dart/service_card.dart';
import 'package:flutter/material.dart';

import '../../router.dart';

class Warranty extends StatelessWidget {
  final List<WarrantyList> warrantyList;

  Warranty({super.key, required this.warrantyList});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(
          height: 20,
        ),
        Expanded(
          child: ListView.builder(
            itemCount: warrantyList.length,
            itemBuilder: (BuildContext context, index) {
              WarrantyList warranty = warrantyList[index];
              return GestureDetector(
                onTap: () {
                  // Define your onTap action here
                  print('Warranty ${warranty.warrantyId} pressed');
                  // You can navigate to another screen or perform any other action here
                  Navigator.pushNamed(context, AppRoutes.warrentyDetailsScreen,arguments: warranty);
                },
                child: ServiceCard(
                  serviceNumber: '${index + 1} ${warranty.item}',
                  serviceId: 'S-ID : ${warranty.warrantyId}',
                  date: "${warranty.createdAt}", // Assuming createdAt is the date field
                  status: warranty.inspectionReport,
                  statusColor: warranty.inspectionReport == 'Completed' ? Colors.green : Colors.red,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}