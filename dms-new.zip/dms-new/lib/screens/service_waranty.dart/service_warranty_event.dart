
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class ServiceWarrantyEvent extends BaseEquatable {}

class ServiceWarrantyInitialEvent extends ServiceWarrantyEvent {
  BuildContext? context;
  dynamic arguments;

  ServiceWarrantyInitialEvent({this.context});

}

class GetVehicleEvent extends ServiceWarrantyEvent {
  GetVehicleEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}

class GetServicesEvent extends ServiceWarrantyEvent {
  GetServicesEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}

class GetWarrantyEvent extends ServiceWarrantyEvent {
  GetWarrantyEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}


class GetBookServiceCustomerEvent extends ServiceWarrantyEvent {
  GetBookServiceCustomerEvent({this.context, this.arguments});
  BuildContext? context;
  dynamic arguments;
}

