// To parse this JSON data, do
//
//     final getServices = getServicesFromJson(jsonString);

import 'dart:convert';

GetServices getServicesFromJson(String str) => GetServices.fromJson(json.decode(str));

String getServicesToJson(GetServices data) => json.encode(data.toJson());

class GetServices {
  List<Datum> data;
  String status;

  GetServices({
    required this.data,
    required this.status,
  });

  factory GetServices.fromJson(Map<String, dynamic> json) => GetServices(
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "status": status,
  };
}

class Datum {
  int id;
  String dealerId;
  String serviceId;
  int customerId;
  String selectVehicle;
  String chasisNumber;
  String numberService;
  String meterReading;
  String repeatJob;
  String rsaOnSite;
  dynamic requestRectification;
  List<AdditionalWork> additionalWorks;
  String invoiceId;
  List<AdditionalWork> remarks;
  String fileUrl;
  String notes;
  String status;
  DateTime createdAt;
  DateTime updatedAt;

  Datum({
    required this.id,
    required this.dealerId,
    required this.serviceId,
    required this.customerId,
    required this.selectVehicle,
    required this.chasisNumber,
    required this.numberService,
    required this.meterReading,
    required this.repeatJob,
    required this.rsaOnSite,
    required this.requestRectification,
    required this.additionalWorks,
    required this.invoiceId,
    required this.remarks,
    required this.fileUrl,
    required this.notes,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    dealerId: json["dealer_id"],
    serviceId: json["service_id"],
    customerId: json["customer_id"],
    selectVehicle: json["select_vehicle"],
    chasisNumber: json["chasis_number"],
    numberService: json["number_service"],
    meterReading: json["meter_reading"],
    repeatJob: json["repeat_job"],
    rsaOnSite: json["rsa_on_site"],
    requestRectification: json["request_rectification"],
    additionalWorks: List<AdditionalWork>.from(json["additional_works"].map((x) => AdditionalWork.fromJson(x))),
    invoiceId: json["invoice_id"],
    remarks: List<AdditionalWork>.from(json["remarks"].map((x) => AdditionalWork.fromJson(x))),
    fileUrl: json["file_url"],
    notes: json["notes"],
    status: json["status"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "dealer_id": dealerId,
    "service_id": serviceId,
    "customer_id": customerId,
    "select_vehicle": selectVehicle,
    "chasis_number": chasisNumber,
    "number_service": numberService,
    "meter_reading": meterReading,
    "repeat_job": repeatJob,
    "rsa_on_site": rsaOnSite,
    "request_rectification": requestRectification,
    "additional_works": List<dynamic>.from(additionalWorks.map((x) => x.toJson())),
    "invoice_id": invoiceId,
    "remarks": List<dynamic>.from(remarks.map((x) => x.toJson())),
    "file_url": fileUrl,
    "notes": notes,
    "status": status,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class AdditionalWork {
  int fieldId;
  String? value;

  AdditionalWork({
    required this.fieldId,
    required this.value,
  });

  factory AdditionalWork.fromJson(Map<String, dynamic> json) => AdditionalWork(
    fieldId: json["field_id"],
    value: json["value"],
  );

  Map<String, dynamic> toJson() => {
    "field_id": fieldId,
    "value": value,
  };
}
