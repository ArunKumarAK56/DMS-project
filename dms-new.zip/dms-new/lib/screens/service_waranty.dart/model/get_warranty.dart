import 'dart:convert';

GetWarranty getWarrantyFromJson(String str) => GetWarranty.fromJson(json.decode(str));

String getWarrantyToJson(GetWarranty data) => json.encode(data.toJson());

class GetWarranty {
  List<WarrantyList> data;
  String status;

  GetWarranty({
    required this.data,
    required this.status,
  });

  factory GetWarranty.fromJson(Map<String, dynamic> json) => GetWarranty(
    data: List<WarrantyList>.from(json["data"].map((x) => WarrantyList.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "status": status,
  };
}

class WarrantyList {
  int id;
  String warrantyId;
  String oemId;
  String dealerId;
  String dealerName;
  String customerId;
  String customerName;
  String productType;
  String selectVehicle;
  String hsnNo;
  String chasisNumber;
  String item;
  String itemNo;
  String itemBrand;
  String stillWarranty;
  String capacity;
  String issue;
  dynamic others;
  String remarks;
  String fileUrl;
  int warrantyCreated;
  DateTime warrantyCreatedDate;
  int claimVerification;
  String claimVerificationDate;
  int inTransit;
  DateTime inTransitDate;
  NTransitDetails inTransitDetails;
  int inspection;
  DateTime inspectionDate;
  String inspectionReport;
  String inspectionRemarks;
  int underServiceReplace;
  DateTime underServiceReplaceDate;
  UnderServiceReplaceDetails underServiceReplaceDetails;
  int returning;
  DateTime returningDate;
  NTransitDetails returnTransitDetails;
  int outForDelivery;
  DateTime outForDeliveryDate;
  DateTime createdAt;
  DateTime updatedAt;

  WarrantyList({
    required this.id,
    required this.warrantyId,
    required this.oemId,
    required this.dealerId,
    required this.dealerName,
    required this.customerId,
    required this.customerName,
    required this.productType,
    required this.selectVehicle,
    required this.hsnNo,
    required this.chasisNumber,
    required this.item,
    required this.itemNo,
    required this.itemBrand,
    required this.stillWarranty,
    required this.capacity,
    required this.issue,
    required this.others,
    required this.remarks,
    required this.fileUrl,
    required this.warrantyCreated,
    required this.warrantyCreatedDate,
    required this.claimVerification,
    required this.claimVerificationDate,
    required this.inTransit,
    required this.inTransitDate,
    required this.inTransitDetails,
    required this.inspection,
    required this.inspectionDate,
    required this.inspectionReport,
    required this.inspectionRemarks,
    required this.underServiceReplace,
    required this.underServiceReplaceDate,
    required this.underServiceReplaceDetails,
    required this.returning,
    required this.returningDate,
    required this.returnTransitDetails,
    required this.outForDelivery,
    required this.outForDeliveryDate,
    required this.createdAt,
    required this.updatedAt,
  });

  factory WarrantyList.fromJson(Map<String, dynamic> json) => WarrantyList(
    id: json["id"],
    warrantyId: json["warranty_id"],
    oemId: json["oem_id"],
    dealerId: json["dealer_id"],
    dealerName: json["dealer_name"],
    customerId: json["customer_id"],
    customerName: json["customer_name"],
    productType: json["product_type"],
    selectVehicle: json["select_vehicle"],
    hsnNo: json["hsn_no"],
    chasisNumber: json["chasis_number"],
    item: json["item"],
    itemNo: json["item_no"],
    itemBrand: json["item_brand"],
    stillWarranty: json["still_warranty"],
    capacity: json["capacity"],
    issue: json["issue"],
    others: json["others"],
    remarks: json["remarks"],
    fileUrl: json["file_url"],
    warrantyCreated: json["warranty_created"],
    warrantyCreatedDate: DateTime.parse(json["warranty_created_date"]),
    claimVerification: json["claim_verification"],
    claimVerificationDate: json["claim_verification_date"],
    inTransit: json["in_transit"],
    inTransitDate: DateTime.parse(json["in_transit_date"]),
    inTransitDetails: NTransitDetails.fromJson(json["in_transit_details"]),
    inspection: json["inspection"],
    inspectionDate: DateTime.parse(json["inspection_date"]),
    inspectionReport: json["inspection_report"],
    inspectionRemarks: json["inspection_remarks"],
    underServiceReplace: json["under_service_replace"],
    underServiceReplaceDate: DateTime.parse(json["under_service_replace_date"]),
    underServiceReplaceDetails: UnderServiceReplaceDetails.fromJson(json["under_service_replace_details"]),
    returning: json["returning"],
    returningDate: DateTime.parse(json["returning_date"]),
    returnTransitDetails: NTransitDetails.fromJson(json["return_transit_details"]),
    outForDelivery: json["out_for_delivery"],
    outForDeliveryDate: DateTime.parse(json["out_for_delivery_date"]),
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "warranty_id": warrantyId,
    "oem_id": oemId,
    "dealer_id": dealerId,
    "dealer_name": dealerName,
    "customer_id": customerId,
    "customer_name": customerName,
    "product_type": productType,
    "select_vehicle": selectVehicle,
    "hsn_no": hsnNo,
    "chasis_number": chasisNumber,
    "item": item,
    "item_no": itemNo,
    "item_brand": itemBrand,
    "still_warranty": stillWarranty,
    "capacity": capacity,
    "issue": issue,
    "others": others,
    "remarks": remarks,
    "file_url": fileUrl,
    "warranty_created": warrantyCreated,
    "warranty_created_date": "${warrantyCreatedDate.year.toString().padLeft(4, '0')}-${warrantyCreatedDate.month.toString().padLeft(2, '0')}-${warrantyCreatedDate.day.toString().padLeft(2, '0')}",
    "claim_verification": claimVerification,
    "claim_verification_date": claimVerificationDate,
    "in_transit": inTransit,
    "in_transit_date": "${inTransitDate.year.toString().padLeft(4, '0')}-${inTransitDate.month.toString().padLeft(2, '0')}-${inTransitDate.day.toString().padLeft(2, '0')}",
    "in_transit_details": inTransitDetails.toJson(),
    "inspection": inspection,
    "inspection_date": "${inspectionDate.year.toString().padLeft(4, '0')}-${inspectionDate.month.toString().padLeft(2, '0')}-${inspectionDate.day.toString().padLeft(2, '0')}",
    "inspection_report": inspectionReport,
    "inspection_remarks": inspectionRemarks,
    "under_service_replace": underServiceReplace,
    "under_service_replace_date": "${underServiceReplaceDate.year.toString().padLeft(4, '0')}-${underServiceReplaceDate.month.toString().padLeft(2, '0')}-${underServiceReplaceDate.day.toString().padLeft(2, '0')}",
    "under_service_replace_details": underServiceReplaceDetails.toJson(),
    "returning": returning,
    "returning_date": "${returningDate.year.toString().padLeft(4, '0')}-${returningDate.month.toString().padLeft(2, '0')}-${returningDate.day.toString().padLeft(2, '0')}",
    "return_transit_details": returnTransitDetails.toJson(),
    "out_for_delivery": outForDelivery,
    "out_for_delivery_date": "${outForDeliveryDate.year.toString().padLeft(4, '0')}-${outForDeliveryDate.month.toString().padLeft(2, '0')}-${outForDeliveryDate.day.toString().padLeft(2, '0')}",
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class NTransitDetails {
  String company;
  String contactNumber;
  String transport;
  String trackingId;
  String payment;
  DateTime date;
  String file;

  NTransitDetails({
    required this.company,
    required this.contactNumber,
    required this.transport,
    required this.trackingId,
    required this.payment,
    required this.date,
    required this.file,
  });

  factory NTransitDetails.fromJson(Map<String, dynamic> json) => NTransitDetails(
    company: json["company"],
    contactNumber: json["contact_number"],
    transport: json["transport"],
    trackingId: json["tracking_id"],
    payment: json["payment"],
    date: DateTime.parse(json["date"]),
    file: json["file"],
  );

  Map<String, dynamic> toJson() => {
    "company": company,
    "contact_number": contactNumber,
    "transport": transport,
    "tracking_id": trackingId,
    "payment": payment,
    "date": "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}",
    "file": file,
  };
}

class UnderServiceReplaceDetails {
  bool service;
  String item;
  String productNo;
  String remarks;

  UnderServiceReplaceDetails({
    required this.service,
    required this.item,
    required this.productNo,
    required this.remarks,
  });

  factory UnderServiceReplaceDetails.fromJson(Map<String, dynamic> json) => UnderServiceReplaceDetails(
    service: json["service"],
    item: json["item"],
    productNo: json["product_no"],
    remarks: json["remarks"],
  );

  Map<String, dynamic> toJson() => {
    "service": service,
    "item": item,
    "product_no": productNo,
    "remarks": remarks,
  };
}
