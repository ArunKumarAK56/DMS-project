import 'dart:convert';

GetBookService getBookServiceFromJson(String str) => GetBookService.fromJson(json.decode(str));

String getBookServiceToJson(GetBookService data) => json.encode(data.toJson());

class GetBookService {
  List<ServiceData> data;
  String status;

  GetBookService({
    required this.data,
    required this.status,
  });

  factory GetBookService.fromJson(Map<String, dynamic> json) => GetBookService(
    data: List<ServiceData>.from(json["data"].map((x) => ServiceData.fromJson(x))),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "status": status,
  };
}

class ServiceData {
  int id;
  String? dealerId;
  String? customerId;
  String? noOfService;
  String? vehicle;
  String? chasisNumber;
  String? serviceType;
  DateTime serviceDate;
  String? serviceTime;
  String? remarks;
  String? status;
  String? reason;
  DateTime createdAt;
  DateTime updatedAt;

  ServiceData({
    required this.id,
    required this.dealerId,
    required this.customerId,
    required this.noOfService,
    required this.vehicle,
    required this.chasisNumber,
    required this.serviceType,
    required this.serviceDate,
    required this.serviceTime,
    required this.remarks,
    required this.status,
    required this.reason,
    required this.createdAt,
    required this.updatedAt,
  });

  factory ServiceData.fromJson(Map<String, dynamic> json) => ServiceData(
    id: json["id"],
    dealerId: json["dealer_id"] ?? "",  // Handle null case
    customerId: json["customer_id"] ?? "",  // Handle null case
    noOfService: json["no_of_service"] ?? "",  // Handle null case
    vehicle: json["vehicle"] ?? "",  // Handle null case
    chasisNumber: json["chasis_number"] ?? "",  // Handle null case
    serviceType: json["service_type"] ?? "",  // Handle null case
    serviceDate: DateTime.parse(json["service_date"]),
    serviceTime: json["service_time"] ?? "",  // Handle null case
    remarks: json["remarks"] ?? "",  // Handle null case
    status: json["status"],
    reason: json["reason"] ?? "",  // Handle null case
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "dealer_id": dealerId ?? "",  // Handle null case
    "customer_id": customerId ?? "",  // Handle null case
    "no_of_service": noOfService ?? "",  // Handle null case
    "vehicle": vehicle ?? "",  // Handle null case
    "chasis_number": chasisNumber ?? "",  // Handle null case
    "service_type": serviceType ?? "",  // Handle null case
    "service_date": "${serviceDate.year.toString().padLeft(4, '0')}-${serviceDate.month.toString().padLeft(2, '0')}-${serviceDate.day.toString().padLeft(2, '0')}",
    "service_time": serviceTime ?? "",  // Handle null case
    "remarks": remarks ?? "",  // Handle null case
    "status": status,
    "reason": reason ?? "",  // Handle null case
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}
