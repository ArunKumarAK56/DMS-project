import 'package:dms_dealers/screens/service_details/service_details_screen.dart';
import 'package:dms_dealers/screens/service_waranty.dart/booked_service_card.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_service_by_customer.dart';
import 'package:dms_dealers/screens/service_waranty.dart/model/get_services.dart';
import 'package:dms_dealers/screens/service_waranty.dart/service_card.dart';
import 'package:flutter/material.dart';

import '../../router.dart';

class Service extends StatelessWidget {
  final List<Datum> servicesList;
  final List<ServiceData> getserivesList;

  Service({super.key, required this.servicesList, required this.getserivesList});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 20,
          ),
          BookedServiceCard(getserivesList : getserivesList),
          const SizedBox(
            height: 20,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: servicesList.length,
              itemBuilder: (BuildContext context, index) {
                Datum service = servicesList[index];
                return GestureDetector(
                  onTap: () {
                    // Navigate to ServiceDetailsScreen and pass the service details as arguments
                    Navigator.pushNamed(
                      context,
                      AppRoutes.serviceDetailsScreen,
                      arguments: service,
                    );
                  },
                  child: ServiceCard(
                    serviceNumber: '${index + 1} ${service.numberService}',
                    serviceId: 'S-ID : ${service.serviceId}',
                    date: "${service.createdAt}", // Assuming createdAt is the date field
                    status: service.status,
                    statusColor: service.status == 'Completed' ? Colors.green : Colors.red,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
