
import 'package:flutter/cupertino.dart';

import '../../utils/base_equatable.dart';

abstract class ServiceDetailsEvent extends BaseEquatable {}

class ServiceDetailsEventInitialEvent extends ServiceDetailsEvent {
  BuildContext? context;
  dynamic arguments;

  ServiceDetailsEventInitialEvent({this.context});

}
