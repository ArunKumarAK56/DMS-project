import 'package:dms_dealers/screens/service_details/service_details_event.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../base/base_state.dart';


class ServiceDetailsBloc extends Bloc<ServiceDetailsEvent, BaseState> {
  ServiceDetailsBloc() : super(InitialState());


  @override
  Stream<BaseState> mapEventToState(
      ServiceDetailsEvent event,
      ) async* {
    if (event is ServiceDetailsEventInitialEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }
  }
}