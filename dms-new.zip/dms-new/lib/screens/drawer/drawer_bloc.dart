import 'dart:convert';

import 'package:dms_dealers/screens/drawer/drawer_event.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../base/base_state.dart';
import '../../http/api_repository.dart';
import '../../http/httpurls.dart';
import '../../utils/contants.dart';
import '../../utils/singleton.dart';
import '../about_vehicle/model/get_vehicle.dart';
import '../profile/model/profile_details.dart';

class DrawerBloc extends Bloc<DrawerEvent, BaseState> {
  DrawerBloc() : super(InitialState());

  @override
  Stream<BaseState> mapEventToState(
    DrawerEvent event,
  ) async* {
    if (event is DrawerInitialEvent) {
      yield LoadingState();
      yield SuccessState(successResponse: 'success');
    }else if (event is GetUserVehicleEvent) {
      dynamic response;
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getVehicle}${event.arguments}",
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      debugPrint('state response $returnableValues');

      if (returnableValues is String) {
        response = returnableValues;
      } else {
        debugPrint('state response $returnableValues');
        response = GetVechicle.fromJson(returnableValues);
      }
      yield SuccessState(successResponse: response);
    }else if (event is ProfileDetailsApiEvent) {
      dynamic response;
      yield LoadingState();
      print(event.arguments);
      final dynamic returnableValues = await APIRepository().dynamicRequest(
          "${HttpUrl.getProfileDetails}${FlashSingleton.instance.id}",
          userArguments: jsonEncode(event.arguments),
          method: ApiRequestMethod.get,
          isBearerTokenNeed: true,
          context: event.context);

      response = ProfileDetails.fromJson(returnableValues);

      yield SuccessState(successResponse: response);
    }
  }
}
